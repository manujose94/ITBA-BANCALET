(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["issues-issues-module"],{

/***/ "./src/app/pages/admin/issues/issues.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/admin/issues/issues.module.ts ***!
  \*****************************************************/
/*! exports provided: IssuesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IssuesPageModule", function() { return IssuesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _issues_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./issues.page */ "./src/app/pages/admin/issues/issues.page.ts");







var routes = [
    {
        path: '',
        component: _issues_page__WEBPACK_IMPORTED_MODULE_6__["IssuesPage"]
    }
];
var IssuesPageModule = /** @class */ (function () {
    function IssuesPageModule() {
    }
    IssuesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_issues_page__WEBPACK_IMPORTED_MODULE_6__["IssuesPage"]]
        })
    ], IssuesPageModule);
    return IssuesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/admin/issues/issues.page.html":
/*!*****************************************************!*\
  !*** ./src/app/pages/admin/issues/issues.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n  <ion-content>\r\n      <ion-grid>\r\n          <ion-row>\r\n              <ion-col>\r\n      <ion-item>\r\n          <ion-searchbar [(ngModel)]=\"searchIssue\" (ionChange)=\"searchTipoChanged()\"></ion-searchbar>\r\n          </ion-item>\r\n             <ion-item>\r\n              <ion-label>Seleccionar tipo de consulta</ion-label>\r\n              <ion-select [(ngModel)]=\"type\" (ionChange)=\"searchTipoChanged()\">\r\n                <ion-select-option value=\"0\" selected>Todos</ion-select-option>\r\n                <ion-select-option   *ngFor=\"let tipo of tipos\" value=\"{{tipo.id}}\"  >\r\n                    {{ tipo.name}}\r\n                  </ion-select-option>\r\n                </ion-select>\r\n              </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-button shape=\"round\" (click)=\"searchTipoChanged()\" disabled=\"{{ !onFiltro }}\">  <i class=\" material-icons\">search</i>Search</ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-refresher slot=\"fixed\"\r\n      (ionRefresh)=\"ionRefresh($event)\">\r\n        <ion-refresher-content\r\n          pullingIcon=\"arrow-dropdown\"\r\n          pullingText=\"Tirar para refrescar\"\r\n          refreshingSpinner=\"circles\"\r\n          refreshingText=\"Actualizando...\">\r\n        </ion-refresher-content>\r\n      </ion-refresher>\r\n    <ion-content>\r\n  <ion-list>\r\n   <ion-item button *ngFor=\"let issue of issues\" [routerLink]=\"['/', 'issue-details', issue.key]\">\r\n    <ion-row>\r\n        <ion-col>\r\n                <ion-label class=\"notification-title\" >Nombre: {{ issue.value.name }}&nbsp; &nbsp; <small class=\"date-notification\"><strong>Contactado: </strong>&nbsp; {{ issue.value.fechaContacto.substring(0,10) }}</small> </ion-label>\r\n                <p class=\"text-notification\">&nbsp;Asunto: {{ issue.value.asunto }}</p>\r\n        </ion-col>\r\n    </ion-row>\r\n   </ion-item>\r\n  </ion-list>\r\n  </ion-content>\r\n  <script>\r\n      const dualRange = document.querySelector('#dual-range');\r\n      dualRange.value = { lower: 33, upper: 60 };\r\n  </script>\r\n"

/***/ }),

/***/ "./src/app/pages/admin/issues/issues.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/admin/issues/issues.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL2lzc3Vlcy9pc3N1ZXMucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/admin/issues/issues.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/admin/issues/issues.page.ts ***!
  \***************************************************/
/*! exports provided: IssuesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IssuesPage", function() { return IssuesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/admin.service */ "./src/app/services/admin.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var IssuesPage = /** @class */ (function () {
    function IssuesPage(alertController, loadingCtrl, events, adminService) {
        this.alertController = alertController;
        this.loadingCtrl = loadingCtrl;
        this.events = events;
        this.adminService = adminService;
        this.searchIssue = '';
        this.onFiltro = false;
        this.tipos = this.adminService.getTipos();
    }
    IssuesPage.prototype.ngOnInit = function () {
        this.getIssues();
    };
    IssuesPage.prototype.getIssues = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando issues..',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.adminService.getIssues().then(function (value) {
                            _this.issues = value.data.ayudas.entry;
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    IssuesPage.prototype.getIssuesFiltro = function (name, tipo) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando filtros...',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        name = this.searchIssue;
                        this.adminService.getIssuesFiltro(name, tipo).then(function (value) {
                            _this.issues = value.data.ayudas.entry;
                            _this.tipoSelected = 0;
                            loading.dismiss();
                        }).catch(function (error) {
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    IssuesPage.prototype.searchTipoChanged = function () {
        this.onFiltro = true;
        this.tipoSelected = this.type;
        this.getIssuesFiltro(this.searchIssue, this.tipoSelected);
    };
    IssuesPage.prototype.ionRefresh = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getIssues()];
                    case 1:
                        _a.sent();
                        event.target.complete();
                        return [2 /*return*/];
                }
            });
        });
    };
    IssuesPage.prototype.ionViewDidEnter = function () {
        this.getIssues();
    };
    IssuesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-issues',
            template: __webpack_require__(/*! ./issues.page.html */ "./src/app/pages/admin/issues/issues.page.html"),
            styles: [__webpack_require__(/*! ./issues.page.scss */ "./src/app/pages/admin/issues/issues.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"],
            src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_2__["AdminService"]])
    ], IssuesPage);
    return IssuesPage;
}());



/***/ })

}]);
//# sourceMappingURL=issues-issues-module.js.map