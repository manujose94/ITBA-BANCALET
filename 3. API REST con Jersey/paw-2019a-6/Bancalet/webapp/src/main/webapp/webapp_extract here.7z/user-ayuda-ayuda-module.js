(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-ayuda-ayuda-module"],{

/***/ "./src/app/pages/user/ayuda/ayuda.module.ts":
/*!**************************************************!*\
  !*** ./src/app/pages/user/ayuda/ayuda.module.ts ***!
  \**************************************************/
/*! exports provided: AyudaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AyudaPageModule", function() { return AyudaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ayuda_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ayuda.page */ "./src/app/pages/user/ayuda/ayuda.page.ts");







var routes = [
    {
        path: '',
        component: _ayuda_page__WEBPACK_IMPORTED_MODULE_6__["AyudaPage"]
    }
];
var AyudaPageModule = /** @class */ (function () {
    function AyudaPageModule() {
    }
    AyudaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_ayuda_page__WEBPACK_IMPORTED_MODULE_6__["AyudaPage"]]
        })
    ], AyudaPageModule);
    return AyudaPageModule;
}());



/***/ }),

/***/ "./src/app/pages/user/ayuda/ayuda.page.html":
/*!**************************************************!*\
  !*** ./src/app/pages/user/ayuda/ayuda.page.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button>\r\n          <i class=\" material-icons\">menu</i>\r\n      </ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>¿Necesitas ayuda?</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form  [formGroup]=\"contactUserForm\">\r\n    <ion-grid>\r\n      <ion-row justify-content-center>\r\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\r\n          <ion-item>\r\n              <ion-input  name=\"asunto\" formControlName=\"asunto\" type=\"text\" placeholder=\"Resume tu problema\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.asunto\">\r\n                <div class=\"error-message\" *ngIf=\"contactUserForm.get('asunto').hasError(validation.type) && (contactUserForm.get('asunto').dirty || contactUserForm.get('asunto').touched)\">\r\n                  <ion-text color=\"warning\">\r\n                  {{ validation.message }}\r\n                </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input name=\"mensaje\" formControlName=\"mensaje\" type=\"text\" placeholder=\"Describe tu problema\" clearInput  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.mensaje\">\r\n                <div class=\"error-message\" *ngIf=\"contactUserForm.get('mensaje').hasError(validation.type) && (contactUserForm.get('mensaje').dirty || contactUserForm.get('mensaje').touched)\">\r\n                  <ion-text color=\"warning\">\r\n                  {{ validation.message }}\r\n                </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n          <ion-button shape=\"round\" expand=\"full\"  color=\"primary\" [disabled]=\"!contactUserForm.valid\" (click)=\"contactar()\" tappable>\r\n              <i class=\" material-icons\">exit_to_app</i>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/pages/user/ayuda/ayuda.page.scss":
/*!**************************************************!*\
  !*** ./src/app/pages/user/ayuda/ayuda.page.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".error {\n  color: #df3e3e;\n  font-size: 11px; }\n\n.error1 {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000; }\n\n.validation-error {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000;\n  font-size: 11px; }\n\nion-item {\n  --color: #3880ff;\n  --background: #fff; }\n\nion-button {\n  --background: #062f77; }\n\n.flag-icon-background {\n  background-size: contain;\n  background-position: 50%;\n  background-repeat: no-repeat; }\n\n.flag-icon {\n  background-size: contain;\n  background-position: 50%;\n  background-repeat: no-repeat;\n  position: relative;\n  display: inline-block;\n  width: 1.33333333em;\n  line-height: 1em; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlci9heXVkYS9DOlxcaXRiYVxcd3NcXHBhdy0yMDE5YS02XFxCYW5jYWxldFxcd2ViYXBwXFxyZXN0Y2xpZW50L3NyY1xcYXBwXFxwYWdlc1xcdXNlclxcYXl1ZGFcXGF5dWRhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQXVCO0VBQ3ZCLGVBQWUsRUFBQTs7QUFHakI7RUFDRSxjQUFzQjtFQUN0QixnQ0FBZ0MsRUFBQTs7QUFHbEM7RUFDRSxjQUFzQjtFQUN0QixnQ0FBZ0M7RUFDaEMsZUFBZSxFQUFBOztBQUVuQjtFQUNJLGdCQUFRO0VBQ1Isa0JBQWEsRUFBQTs7QUFHakI7RUFDSSxxQkFBYSxFQUFBOztBQUlqQjtFQUNJLHdCQUF3QjtFQUN4Qix3QkFBd0I7RUFDeEIsNEJBQTRCLEVBQUE7O0FBRTlCO0VBQ0Usd0JBQXdCO0VBQ3hCLHdCQUF3QjtFQUN4Qiw0QkFBNEI7RUFDNUIsa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQixtQkFBbUI7RUFDbkIsZ0JBQWdCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy91c2VyL2F5dWRhL2F5dWRhLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lcnJvciB7XHJcbiAgICBjb2xvcjogcmdiKDIyMywgNjIsIDYyKTtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICB9XHJcblxyXG4gIC5lcnJvcjEge1xyXG4gICAgY29sb3I6IHJnYig3NSwgNzUsIDc1KTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmYwMDAwO1xyXG4gIH1cclxuXHJcbiAgLnZhbGlkYXRpb24tZXJyb3Ige1xyXG4gICAgY29sb3I6IHJnYig3NSwgNzUsIDc1KTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmYwMDAwO1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gIH1cclxuaW9uLWl0ZW17XHJcbiAgICAtLWNvbG9yOiAjMzg4MGZmO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG59XHJcblxyXG5pb24tYnV0dG9ue1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMDYyZjc3O1xyXG59XHJcblxyXG4gICAgXHJcbi5mbGFnLWljb24tYmFja2dyb3VuZCB7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiA1MCU7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIH1cclxuICAuZmxhZy1pY29uIHtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IDUwJTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMS4zMzMzMzMzM2VtO1xyXG4gICAgbGluZS1oZWlnaHQ6IDFlbTtcclxuICB9XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/user/ayuda/ayuda.page.ts":
/*!************************************************!*\
  !*** ./src/app/pages/user/ayuda/ayuda.page.ts ***!
  \************************************************/
/*! exports provided: AyudaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AyudaPage", function() { return AyudaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");





var AyudaPage = /** @class */ (function () {
    function AyudaPage(navCtrl, menuCtrl, loadingCtrl, formBuilder, usersService, alertCtrl, toastCtrl) {
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.loadingCtrl = loadingCtrl;
        this.formBuilder = formBuilder;
        this.usersService = usersService;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.validation_messages = {
            'asunto': [
                { type: 'required', message: 'Debes introducir un nombre de usuario.' },
                { type: 'minlength', message: 'El nombre de usuario debe tener al menos 6 caracteres.' },
                { type: 'maxlength', message: 'El nombre de usuario no puede superar los 15 caracteres.' },
                { type: 'pattern', message: 'El usuario solamente puede contener números o letras.' },
                { type: 'validUsername', message: 'El usuario ya esta en uso.' }
            ],
            'mensaje': [
                { type: 'required', message: 'Debes introducir un nombre de usuario.' },
                { type: 'minlength', message: 'El nombre de usuario debe tener al menos 6 caracteres.' },
                { type: 'maxlength', message: 'El nombre de usuario no puede superar los 15 caracteres.' },
                { type: 'pattern', message: 'El usuario solamente puede contener números o letras.' },
                { type: 'validUsername', message: 'El usuario ya esta en uso.' }
            ]
        };
    }
    AyudaPage.prototype.ngOnInit = function () {
        this.contactUserForm = this.formBuilder.group({
            asunto: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            mensaje: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(500), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
        });
    };
    AyudaPage.prototype.contactar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.formulario = {
                            name: "USUARIOLOGUEADO",
                            email: "USUARIOLOGUEADO@email",
                            subject: this.contactUserForm.value.asunto,
                            mensaje: this.contactUserForm.value.mensaje
                        };
                        return [4 /*yield*/, this.alertCtrl.create({
                                header: 'Enviar mensaje',
                                message: '¿Estas seguro de que quieres enviar el mensaje?',
                                buttons: [
                                    {
                                        text: 'Cancelar',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                    }, {
                                        text: 'Confirmar',
                                        handler: function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                            var loading;
                                            var _this = this;
                                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                                switch (_a.label) {
                                                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                                                            message: 'Enviando mensaje... ',
                                                            translucent: true,
                                                        })];
                                                    case 1:
                                                        loading = _a.sent();
                                                        return [4 /*yield*/, loading.present()];
                                                    case 2:
                                                        _a.sent();
                                                        this.usersService.contactarAdminlogin(this.formulario).then(function (value) {
                                                            _this.presentToast(value.data.mensaje);
                                                            loading.dismiss();
                                                        }).catch(function (error) {
                                                            loading.dismiss();
                                                            _this.presentToast('Ha surgido un problema');
                                                        });
                                                        return [2 /*return*/];
                                                }
                                            });
                                        }); }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AyudaPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 10000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    AyudaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ayuda',
            template: __webpack_require__(/*! ./ayuda.page.html */ "./src/app/pages/user/ayuda/ayuda.page.html"),
            styles: [__webpack_require__(/*! ./ayuda.page.scss */ "./src/app/pages/user/ayuda/ayuda.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            src_app_services_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]])
    ], AyudaPage);
    return AyudaPage;
}());



/***/ }),

/***/ "./src/app/services/users.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../providers/settings */ "./src/app/providers/settings.ts");







var UsersService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UsersService, _super);
    function UsersService(http, settings) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.url2 = './../assets/data/countrys.json';
        settings.getValue('AuthToken').then(function (value) {
            _this.token = value;
            return value;
        });
        return _this;
    }
    UsersService.prototype.getUserInfo = function () {
        return this.currentUser;
    };
    UsersService.prototype.getUserPrincipal = function () {
        var _this = this;
        if (this.currentUser) {
            return this.currentUser;
        }
        else {
            return new Promise(function (resolve) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.settings.load().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                var _this = this;
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.getUserUsername(this.settings.allSettings.user.username).then(function (response) {
                                                _this.currentUserId = response.data.id;
                                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                                _this.currentUser = response.data.user;
                                            }).catch(function (error) {
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            }); })];
                        case 1:
                            _a.sent();
                            resolve(this.currentUser);
                            return [2 /*return*/];
                    }
                });
            }); });
        }
    };
    UsersService.prototype.getIdUserInfo = function () {
        return this.currentUserId;
    };
    UsersService.prototype.getCountrys = function () {
        var _this = this;
        return new Promise(function (resolve) {
            _this.http.get(_this.url2).
                pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) { return response; })).
                subscribe(function (data) {
                {
                    _this.countrys = data;
                    resolve(_this.countrys);
                }
            });
        });
    };
    UsersService.prototype.getUserId = function (id) {
        return this.instance.get('rest/users/' + id);
    };
    UsersService.prototype.getUserUsername = function (username) {
        this.init();
        return this.instance.get('rest/users/login/' + username);
    };
    UsersService.prototype.getUsersDTO = function () {
        return this.instance.get('rest/users');
    };
    UsersService.prototype.getHistorialCompra = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscompras');
    };
    UsersService.prototype.getHistorialVentas = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/misventas');
    };
    UsersService.prototype.getMisSugerencias = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('/rest/users/missugerencias');
    };
    UsersService.prototype.getMisMensajesEnviados = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactose');
    };
    UsersService.prototype.getMisMensajesRecibidos = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactosr');
    };
    UsersService.prototype.getMaxVendor = function (id) {
        return this.instance.get('rest/users/getMaxVendor/' + id);
    };
    UsersService.prototype.getMaxBuyer = function (id) {
        return this.instance.get('rest/users/getMaxBuyer/' + id);
    };
    UsersService.prototype.getMaxRated = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.getRate = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.contactarAdminlogin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json', 'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.post('rest/users/help', contactForm);
    };
    UsersService.prototype.updatepass = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/editPass/', user);
    };
    UsersService.prototype.update = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/edit/', user);
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], UsersService);
    return UsersService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ })

}]);
//# sourceMappingURL=user-ayuda-ayuda-module.js.map