(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-item-edititem-edititem-module"],{

/***/ "./src/app/pages/item/edititem/edititem.module.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/item/edititem/edititem.module.ts ***!
  \********************************************************/
/*! exports provided: EdititemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EdititemPageModule", function() { return EdititemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _edititem_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edititem.page */ "./src/app/pages/item/edititem/edititem.page.ts");







var routes = [
    {
        path: '',
        component: _edititem_page__WEBPACK_IMPORTED_MODULE_6__["EdititemPage"]
    }
];
var EdititemPageModule = /** @class */ (function () {
    function EdititemPageModule() {
    }
    EdititemPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_edititem_page__WEBPACK_IMPORTED_MODULE_6__["EdititemPage"]]
        })
    ], EdititemPageModule);
    return EdititemPageModule;
}());



/***/ }),

/***/ "./src/app/pages/item/edititem/edititem.page.html":
/*!********************************************************!*\
  !*** ./src/app/pages/item/edititem/edititem.page.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n          <i class=\" material-icons\">arrow_back</i>\r\n      </ion-buttons>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n\r\n  <ion-content>\r\n    <form  [formGroup]=\"onItemForm\">\r\n      <ion-grid>\r\n        <ion-row color=\"primary\" justify-content-center>\r\n          <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\r\n            <div text-center>\r\n             \r\n              <h3>Actualizar item</h3>\r\n            </div>\r\n            <div padding>\r\n                <ion-item>\r\n                    <ion-label>Tipo</ion-label>\r\n                    <ion-avatar *ngIf=\"tipoID\">\r\n                      <img src=\"assets/img/type_food/{{tipoID}}.png\">\r\n                    </ion-avatar>\r\n                    <ion-select #S placeholder=\"Seleccionar Tipo\"  formControlName=\"tipo\"  (ionChange)=\"onChangeTipo(S.value)\">\r\n                        <ion-select-option   *ngFor=\"let tipo of tipos\" value=\"{{ tipo.id }}\"  >\r\n                           {{ tipo.name }}                   \r\n                        </ion-select-option>\r\n                    </ion-select>\r\n                  </ion-item>\r\n                  <p ion-text *ngIf=\"onItemForm.get('tipo').touched && onItemForm.get('tipo').hasError('required')\">\r\n                      <ion-text color=\"warning\">\r\n                        Campo requerido\r\n                      </ion-text>\r\n                    </p>\r\n              <ion-item>\r\n                  <ion-label position=\"stacked\">Nombre</ion-label>\r\n                <ion-input  name=\"name\" formControlName=\"name\" type=\"text\" placeholder=\"{{item.name}}\"  required></ion-input>\r\n              </ion-item>\r\n              <p ion-text *ngIf=\"onItemForm.get('name').touched && onItemForm.get('name').hasError('required')\">\r\n                  <ion-text color=\"warning\">\r\n                    Campo requerido\r\n                  </ion-text>\r\n                </p>\r\n         \r\n              <ion-item>\r\n                <ion-label position=\"stacked\">Descripcion</ion-label>\r\n                <ion-input name=\"description\"  formControlName=\"description\" type=\"text\" placeholder=\"{{item.description}}\"  required></ion-input>\r\n              </ion-item>\r\n              <p ion-text *ngIf=\"onItemForm.get('description').touched && onItemForm.get('description').hasError('required')\">\r\n                <ion-text color=\"warning\">\r\n                  Campo requerido\r\n                </ion-text>\r\n              </p>\r\n                            \r\n              <ion-item>\r\n                  <ion-label position=\"stacked\">Precio</ion-label>\r\n                <ion-input  name=\"price\"  formControlName=\"price\"  type=\"number\" placeholder=\"{{item.price}}\"  required></ion-input>\r\n              </ion-item>\r\n              <p ion-text *ngIf=\"onItemForm.get('price').touched && onItemForm.get('price').hasError('required')\">\r\n                <ion-text color=\"warning\">\r\n                  Campo requerido\r\n                </ion-text>\r\n              </p>\r\n           \r\n              <ion-item>\r\n                  <i class=\" material-icons\">event</i>\r\n                <ion-label position=\"floating\">YYYY-MM-DD</ion-label>\r\n                <ion-datetime name=\"fecha_caducidad\" formControlName=\"fecha_caducidad\" displayFormat=\"YYYY-MM-DD\" placeholder=\"{{item.fechaCaducidad}}\" min=\"{{today}}\" max=\"2040-12-09\"></ion-datetime>\r\n              </ion-item>\r\n              <p ion-text *ngIf=\"onItemForm.get('fecha_caducidad').touched && onItemForm.get('fecha_caducidad').hasError('required')\">\r\n                <ion-text color=\"warning\">\r\n                  Campo requerido\r\n                </ion-text>\r\n              </p>\r\n              \r\n            </div>\r\n            <ion-button shape=\"round\" expand=\"full\" fill=\"outline\" color=\"success\" [disabled]=\"!onItemForm.valid\"  (click)=\"onUpdateItem()\" tappable>\r\n                <i class=\" material-icons\">add</i>\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </form>\r\n  \r\n  \r\n  </ion-content>\r\n"

/***/ }),

/***/ "./src/app/pages/item/edititem/edititem.page.scss":
/*!********************************************************!*\
  !*** ./src/app/pages/item/edititem/edititem.page.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2l0ZW0vZWRpdGl0ZW0vZWRpdGl0ZW0ucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/item/edititem/edititem.page.ts":
/*!******************************************************!*\
  !*** ./src/app/pages/item/edititem/edititem.page.ts ***!
  \******************************************************/
/*! exports provided: EdititemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EdititemPage", function() { return EdititemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_users_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/users.service */ "./src/app/services/users.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_items_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/items.service */ "./src/app/services/items.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");







var EdititemPage = /** @class */ (function () {
    function EdititemPage(activatedRoute, itemsService, alertCtrl, loadingCtrl, usersService, toastCtrl, formBuilder, navCtrl) {
        this.activatedRoute = activatedRoute;
        this.itemsService = itemsService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.usersService = usersService;
        this.toastCtrl = toastCtrl;
        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.succesAddItem = false;
        this.tipos = this.itemsService.getTipos();
    }
    EdititemPage.prototype.ngOnInit = function () {
        var _this = this;
        var id = this.activatedRoute.snapshot.paramMap.get('id');
        this.itemID = id;
        this.itemsService.getItemsID(id).then(function (value) {
            _this.item = value.data.item;
        }).catch(function (error) {
            if (!error.response) {
                error.response = 'ERROR';
            }
        });
        var today = new Date();
        var day = new Date().getDate();
        var mounth = today.getMonth() + 1;
        var dd;
        var mm;
        var yyyy = today.getFullYear();
        if (day < 10) {
            dd = '0' + day;
        }
        else {
            dd = day.toString();
        }
        if (mounth < 10) {
            mm = '0' + mounth;
        }
        else {
            mm = mounth.toString();
        }
        this.today = yyyy + '-' + mm + '-' + dd;
        this.onItemForm = this.formBuilder.group({
            name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].maxLength(30), _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].pattern('[a-zA-Z ]*'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].maxLength(30), _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].pattern('[a-zA-Z ]*'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            price: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            fecha_caducidad: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            tipo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])]
        });
    };
    EdititemPage.prototype.onUpdateItem = function () {
        this.item = {
            name: this.onItemForm.value.name,
            description: this.onItemForm.value.description,
            price: this.onItemForm.value.price,
            fecha_caducidad: this.onItemForm.value.fecha_caducidad.substring(0, 10),
            tipo: this.onItemForm.value.tipo,
        };
        this.createItem();
    };
    EdititemPage.prototype.onChangeTipo = function (S) {
        this.tipoID = S;
    };
    EdititemPage.prototype.createItem = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Actualizando item... ',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.itemsService.update(this.item, this.itemID).then(function (value) {
                            _this.succesAddItem = true;
                            loading.dismiss();
                            _this.showMessage(value.data.item.name);
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                            _this.presentToast('Error en insertar item: ' + _this.item.name);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    EdititemPage.prototype.showMessage = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: 'Actualizado',
                            subHeader: 'Producto subido con exito',
                            message: text,
                            buttons: [{
                                    text: 'Menu',
                                    handler: function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                            this.navCtrl.navigateRoot('/menu');
                                            return [2 /*return*/];
                                        });
                                    }); }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EdititemPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 4000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    EdititemPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edititem',
            template: __webpack_require__(/*! ./edititem.page.html */ "./src/app/pages/item/edititem/edititem.page.html"),
            styles: [__webpack_require__(/*! ./edititem.page.scss */ "./src/app/pages/item/edititem/edititem.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], src_app_services_items_service__WEBPACK_IMPORTED_MODULE_4__["ItemsService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"], _services_users_service__WEBPACK_IMPORTED_MODULE_2__["UsersService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]])
    ], EdititemPage);
    return EdititemPage;
}());



/***/ }),

/***/ "./src/app/services/users.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../providers/settings */ "./src/app/providers/settings.ts");







var UsersService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UsersService, _super);
    function UsersService(http, settings) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.url2 = './../assets/data/countrys.json';
        settings.getValue('AuthToken').then(function (value) {
            _this.token = value;
            return value;
        });
        return _this;
    }
    UsersService.prototype.getUserInfo = function () {
        return this.currentUser;
    };
    UsersService.prototype.getUserPrincipal = function () {
        var _this = this;
        if (this.currentUser) {
            return this.currentUser;
        }
        else {
            return new Promise(function (resolve) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.settings.load().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                var _this = this;
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.getUserUsername(this.settings.allSettings.user.username).then(function (response) {
                                                _this.currentUserId = response.data.id;
                                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                                _this.currentUser = response.data.user;
                                            }).catch(function (error) {
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            }); })];
                        case 1:
                            _a.sent();
                            resolve(this.currentUser);
                            return [2 /*return*/];
                    }
                });
            }); });
        }
    };
    UsersService.prototype.getIdUserInfo = function () {
        return this.currentUserId;
    };
    UsersService.prototype.getCountrys = function () {
        var _this = this;
        return new Promise(function (resolve) {
            _this.http.get(_this.url2).
                pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) { return response; })).
                subscribe(function (data) {
                {
                    _this.countrys = data;
                    resolve(_this.countrys);
                }
            });
        });
    };
    UsersService.prototype.getUserId = function (id) {
        return this.instance.get('rest/users/' + id);
    };
    UsersService.prototype.getUserUsername = function (username) {
        this.init();
        return this.instance.get('rest/users/login/' + username);
    };
    UsersService.prototype.getUsersDTO = function () {
        return this.instance.get('rest/users');
    };
    UsersService.prototype.getHistorialCompra = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscompras');
    };
    UsersService.prototype.getHistorialVentas = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/misventas');
    };
    UsersService.prototype.getMisSugerencias = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('/rest/users/missugerencias');
    };
    UsersService.prototype.getMisMensajesEnviados = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactose');
    };
    UsersService.prototype.getMisMensajesRecibidos = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactosr');
    };
    UsersService.prototype.getMaxVendor = function (id) {
        return this.instance.get('rest/users/getMaxVendor/' + id);
    };
    UsersService.prototype.getMaxBuyer = function (id) {
        return this.instance.get('rest/users/getMaxBuyer/' + id);
    };
    UsersService.prototype.getMaxRated = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.getRate = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.contactarAdminlogin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json', 'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.post('rest/users/help', contactForm);
    };
    UsersService.prototype.updatepass = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/editPass/', user);
    };
    UsersService.prototype.update = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/edit/', user);
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], UsersService);
    return UsersService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ })

}]);
//# sourceMappingURL=pages-item-edititem-edititem-module.js.map