(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-user-user-user-module"],{

/***/ "./src/app/pages/user/user/user.module.ts":
/*!************************************************!*\
  !*** ./src/app/pages/user/user/user.module.ts ***!
  \************************************************/
/*! exports provided: UserPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserPageModule", function() { return UserPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _user_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user.page */ "./src/app/pages/user/user/user.page.ts");







var routes = [
    {
        path: '',
        component: _user_page__WEBPACK_IMPORTED_MODULE_6__["UserPage"]
    }
];
var UserPageModule = /** @class */ (function () {
    function UserPageModule() {
    }
    UserPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_user_page__WEBPACK_IMPORTED_MODULE_6__["UserPage"]]
        })
    ], UserPageModule);
    return UserPageModule;
}());



/***/ }),

/***/ "./src/app/pages/user/user/user.page.html":
/*!************************************************!*\
  !*** ./src/app/pages/user/user/user.page.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-back-button>\r\n          <i class=\" material-icons\">arrow_back</i>\r\n      </ion-back-button>\r\n        </ion-buttons>\r\n    <ion-title>Mi Perfil</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-card>\r\n        <ion-card-header>\r\n          \r\n            <ion-card-title>\r\n                <ion-item lines=\"none\">\r\n                    <ion-avatar slot=\"start\">\r\n                        <img src=\"assets/img/avatar/avatar{{ user.numImg }}.png\">\r\n                      </ion-avatar>\r\n                      {{user.username}} \r\n                </ion-item>\r\n                <ion-chip *ngIf=\"isMaxBuyer\">\r\n                  <ion-avatar>\r\n                    <img src=\"assets/img/bestbuyer.png\">\r\n                  </ion-avatar>\r\n                  <ion-label>Mejor Comprador</ion-label>\r\n                 \r\n                </ion-chip>\r\n                <ion-chip  *ngIf=\"isMaxRated\">\r\n                  <ion-avatar>\r\n                    <img src=\"assets/img/bestrated.png\">\r\n                  </ion-avatar>\r\n                  <ion-label>Mejores Valoraciones</ion-label>\r\n                  \r\n                </ion-chip>\r\n                <ion-chip *ngIf=\"isMaxVendedor\">\r\n                  <ion-avatar>\r\n                    <img src=\"assets/img/bestseller.png\">\r\n                  </ion-avatar>\r\n                  <ion-label>Mejor Vendedor</ion-label>\r\n                  \r\n                </ion-chip>\r\n            </ion-card-title>\r\n            <ion-button shape=\"round\" fill=\"outline\" color=\"secondary\" [routerLink]=\"['/', 'edituser', id]\" >Editar</ion-button>\r\n            <ion-button shape=\"round\" fill=\"outline\" color=\"danger\" [routerLink]=\"['/', 'editpass', id]\" >Cambiar contraseña</ion-button>\r\n\r\n        </ion-card-header>\r\n      \r\n        <ion-card-content>\r\n         \r\n          <ion-item lines=\"none\">\r\n            <i class=\" material-icons\">mail</i>\r\n          <ion-label >{{user.email}}</ion-label>\r\n        </ion-item>\r\n              \r\n        <ion-item>\r\n          <i class=\" material-icons\">face</i>\r\n          <ion-label >{{user.telf}}</ion-label>\r\n        </ion-item>\r\n         \r\n        <ion-item>\r\n          <i class=\" material-icons\">map</i>\r\n        <ion-label>{{user.city}}</ion-label>\r\n      </ion-item>\r\n      \r\n      \r\n      <ion-item>\r\n          <i class=\" material-icons\">markunread_mailbox</i>\r\n        <ion-label  >{{user.direccion}}</ion-label>\r\n      </ion-item>\r\n      \r\n      <ion-item>\r\n          \r\n          <i class=\" material-icons\">room</i>\r\n        <ion-label   >{{user.code}}</ion-label>\r\n      </ion-item>\r\n      \r\n\r\n    \r\n      <ion-item>\r\n          <i class=\" material-icons\">flag</i>\r\n          <ion-label >{{user.country}}</ion-label>\r\n          \r\n        </ion-item>\r\n        </ion-card-content>\r\n      </ion-card>\r\n\r\n      \r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/pages/user/user/user.page.scss":
/*!************************************************!*\
  !*** ./src/app/pages/user/user/user.page.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3VzZXIvdXNlci91c2VyLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/user/user/user.page.ts":
/*!**********************************************!*\
  !*** ./src/app/pages/user/user/user.page.ts ***!
  \**********************************************/
/*! exports provided: UserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserPage", function() { return UserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");






var UserPage = /** @class */ (function () {
    function UserPage(activatedRoute, usersService, alertCtrl, loadingCtrl) {
        this.activatedRoute = activatedRoute;
        this.usersService = usersService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    UserPage.prototype.ngOnInit = function () {
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        this.getUserInfo(this.id);
    };
    UserPage.prototype.ionViewWillEnter = function () {
        this.getUserInfo(this.id);
    };
    UserPage.prototype.getUserInfo = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando Datos de Perfil...',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["forkJoin"])(this.usersService.getUserId(id).then(function (userdata) {
                            _this.user = userdata.data.user;
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                        }), this.usersService.getMaxBuyer(id).then(function (isbuyer) {
                            _this.isMaxBuyer = isbuyer.data.value;
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            _this.isMaxBuyer = false;
                        }), this.usersService.getMaxRated(id).then(function (ismaxrated) {
                            _this.isMaxRated = ismaxrated.data.value;
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            _this.isMaxRated = false;
                        }), this.usersService.getMaxVendor(id).then(function (ismaxven) {
                            _this.isMaxVendedor = ismaxven.data.value;
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            _this.isMaxVendedor = false;
                        })).subscribe(function (_a) {
                            var userdata = _a[0], isbuyer = _a[1], ismaxven = _a[2], ismaxrated = _a[3];
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    UserPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user',
            template: __webpack_require__(/*! ./user.page.html */ "./src/app/pages/user/user/user.page.html"),
            styles: [__webpack_require__(/*! ./user.page.scss */ "./src/app/pages/user/user/user.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_services_users_service__WEBPACK_IMPORTED_MODULE_3__["UsersService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])
    ], UserPage);
    return UserPage;
}());



/***/ }),

/***/ "./src/app/services/users.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../providers/settings */ "./src/app/providers/settings.ts");







var UsersService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UsersService, _super);
    function UsersService(http, settings) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.url2 = './../assets/data/countrys.json';
        settings.getValue('AuthToken').then(function (value) {
            _this.token = value;
            return value;
        });
        return _this;
    }
    UsersService.prototype.getUserInfo = function () {
        return this.currentUser;
    };
    UsersService.prototype.getUserPrincipal = function () {
        var _this = this;
        if (this.currentUser) {
            return this.currentUser;
        }
        else {
            return new Promise(function (resolve) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.settings.load().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                var _this = this;
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.getUserUsername(this.settings.allSettings.user.username).then(function (response) {
                                                _this.currentUserId = response.data.id;
                                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                                _this.currentUser = response.data.user;
                                            }).catch(function (error) {
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            }); })];
                        case 1:
                            _a.sent();
                            resolve(this.currentUser);
                            return [2 /*return*/];
                    }
                });
            }); });
        }
    };
    UsersService.prototype.getIdUserInfo = function () {
        return this.currentUserId;
    };
    UsersService.prototype.getCountrys = function () {
        var _this = this;
        return new Promise(function (resolve) {
            _this.http.get(_this.url2).
                pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) { return response; })).
                subscribe(function (data) {
                {
                    _this.countrys = data;
                    resolve(_this.countrys);
                }
            });
        });
    };
    UsersService.prototype.getUserId = function (id) {
        return this.instance.get('rest/users/' + id);
    };
    UsersService.prototype.getUserUsername = function (username) {
        this.init();
        return this.instance.get('rest/users/login/' + username);
    };
    UsersService.prototype.getUsersDTO = function () {
        return this.instance.get('rest/users');
    };
    UsersService.prototype.getHistorialCompra = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscompras');
    };
    UsersService.prototype.getHistorialVentas = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/misventas');
    };
    UsersService.prototype.getMisSugerencias = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('/rest/users/missugerencias');
    };
    UsersService.prototype.getMisMensajesEnviados = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactose');
    };
    UsersService.prototype.getMisMensajesRecibidos = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactosr');
    };
    UsersService.prototype.getMaxVendor = function (id) {
        return this.instance.get('rest/users/getMaxVendor/' + id);
    };
    UsersService.prototype.getMaxBuyer = function (id) {
        return this.instance.get('rest/users/getMaxBuyer/' + id);
    };
    UsersService.prototype.getMaxRated = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.getRate = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.contactarAdminlogin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json', 'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.post('rest/users/help', contactForm);
    };
    UsersService.prototype.updatepass = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/editPass/', user);
    };
    UsersService.prototype.update = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/edit/', user);
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], UsersService);
    return UsersService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ })

}]);
//# sourceMappingURL=pages-user-user-user-module.js.map