(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe"],{

/***/ "./src/app/services/auth/auth.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/auth/auth.service.ts ***!
  \***********************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _users_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../users.service */ "./src/app/services/users.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var src_app_providers_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/providers/settings */ "./src/app/providers/settings.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _items_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../items.service */ "./src/app/services/items.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);










var TOKEN_KEY = 'AuthToken';
var AuthService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](AuthService, _super);
    function AuthService(http, settings, usersService, itemsService) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.usersService = usersService;
        _this.itemsService = itemsService;
        _this.authState = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](false);
        _this.user = _this.authState
            .asObservable()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(function (response) { return response; }));
        return _this;
    }
    AuthService.prototype.loadUser = function () {
        var _this = this;
        this.settings.storage.get(TOKEN_KEY).then(function (data) {
            if (data) {
                _this.authState.next(data);
            }
            else {
                _this.authState.next(false);
            }
        });
    };
    AuthService.prototype.signIn = function (token) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.authState.next(true);
                        return [4 /*yield*/, this.settings.storeUserCredentials(token)];
                    case 1:
                        _a.sent();
                        this.setTokenServices(token);
                        return [2 /*return*/];
                }
            });
        });
    };
    AuthService.prototype.loginDTO = function (username, password) {
        this.token = null;
        var urlSearchParams = new URLSearchParams();
        urlSearchParams.append('username', username);
        urlSearchParams.append('password', password);
        return this.instance.post('rest/login', urlSearchParams);
    };
    AuthService.prototype.register = function (registerform) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_9___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        return this.instance.post('rest/register', registerform);
    };
    AuthService.prototype.confirmregister = function (id) {
        return this.instance.put('rest/confirmregister/' + id);
    };
    AuthService.prototype.contactAdmin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_9___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        return this.instance.post('rest/contact', contactForm);
    };
    AuthService.prototype.setTokenServices = function (token) {
        this.usersService.setToken(token);
        this.itemsService.setToken(token);
        this.setToken(token);
    };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], src_app_providers_settings__WEBPACK_IMPORTED_MODULE_4__["SettingsProvider"],
            _users_service__WEBPACK_IMPORTED_MODULE_1__["UsersService"], _items_service__WEBPACK_IMPORTED_MODULE_7__["ItemsService"]])
    ], AuthService);
    return AuthService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_3__["default"]));



/***/ }),

/***/ "./src/app/services/users.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../providers/settings */ "./src/app/providers/settings.ts");







var UsersService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UsersService, _super);
    function UsersService(http, settings) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.url2 = './../assets/data/countrys.json';
        settings.getValue('AuthToken').then(function (value) {
            _this.token = value;
            return value;
        });
        return _this;
    }
    UsersService.prototype.getUserInfo = function () {
        return this.currentUser;
    };
    UsersService.prototype.getUserPrincipal = function () {
        var _this = this;
        if (this.currentUser) {
            return this.currentUser;
        }
        else {
            return new Promise(function (resolve) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.settings.load().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                var _this = this;
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.getUserUsername(this.settings.allSettings.user.username).then(function (response) {
                                                _this.currentUserId = response.data.id;
                                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                                _this.currentUser = response.data.user;
                                            }).catch(function (error) {
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            }); })];
                        case 1:
                            _a.sent();
                            resolve(this.currentUser);
                            return [2 /*return*/];
                    }
                });
            }); });
        }
    };
    UsersService.prototype.getIdUserInfo = function () {
        return this.currentUserId;
    };
    UsersService.prototype.getCountrys = function () {
        var _this = this;
        return new Promise(function (resolve) {
            _this.http.get(_this.url2).
                pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) { return response; })).
                subscribe(function (data) {
                {
                    _this.countrys = data;
                    resolve(_this.countrys);
                }
            });
        });
    };
    UsersService.prototype.getUserId = function (id) {
        return this.instance.get('rest/users/' + id);
    };
    UsersService.prototype.getUserUsername = function (username) {
        this.init();
        return this.instance.get('rest/users/login/' + username);
    };
    UsersService.prototype.getUsersDTO = function () {
        return this.instance.get('rest/users');
    };
    UsersService.prototype.getHistorialCompra = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscompras');
    };
    UsersService.prototype.getHistorialVentas = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/misventas');
    };
    UsersService.prototype.getMisSugerencias = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('/rest/users/missugerencias');
    };
    UsersService.prototype.getMisMensajesEnviados = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactose');
    };
    UsersService.prototype.getMisMensajesRecibidos = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactosr');
    };
    UsersService.prototype.getMaxVendor = function (id) {
        return this.instance.get('rest/users/getMaxVendor/' + id);
    };
    UsersService.prototype.getMaxBuyer = function (id) {
        return this.instance.get('rest/users/getMaxBuyer/' + id);
    };
    UsersService.prototype.getMaxRated = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.getRate = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.contactarAdminlogin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json', 'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.post('rest/users/help', contactForm);
    };
    UsersService.prototype.updatepass = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/editPass/', user);
    };
    UsersService.prototype.update = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/edit/', user);
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], UsersService);
    return UsersService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ })

}]);
//# sourceMappingURL=default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe.js.map