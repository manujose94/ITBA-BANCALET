(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["users-users-module"],{

/***/ "./src/app/pages/admin/users/users.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/admin/users/users.module.ts ***!
  \***************************************************/
/*! exports provided: UsersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersPageModule", function() { return UsersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _users_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users.page */ "./src/app/pages/admin/users/users.page.ts");







var routes = [
    {
        path: '',
        component: _users_page__WEBPACK_IMPORTED_MODULE_6__["UsersPage"]
    }
];
var UsersPageModule = /** @class */ (function () {
    function UsersPageModule() {
    }
    UsersPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_users_page__WEBPACK_IMPORTED_MODULE_6__["UsersPage"]]
        })
    ], UsersPageModule);
    return UsersPageModule;
}());



/***/ }),

/***/ "./src/app/pages/admin/users/users.page.html":
/*!***************************************************!*\
  !*** ./src/app/pages/admin/users/users.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-grid>\r\n    <ion-row>\r\n        <ion-col>\r\n<ion-item>\r\n    <ion-searchbar [(ngModel)]=\"searchuser\" (ionChange)=\"searchTipoChanged()\"></ion-searchbar>\r\n    </ion-item>\r\n       <ion-item>\r\n        <ion-label>Seleccionar tipo de consulta</ion-label>\r\n        <ion-select [(ngModel)]=\"type\" (ionChange)=\"searchTipoChanged()\">\r\n          <ion-select-option value=\"\" selected>Todos</ion-select-option>\r\n          <ion-select-option value=\"1\" selected>ROLE ADMIN</ion-select-option>\r\n          <ion-select-option value=\"2\" selected>ROLE USER</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col>\r\n          <ion-button shape=\"round\" (click)=\"searchTipoChanged()\" disabled=\"{{ !onFiltro }}\"><i class=\" material-icons\">search</i>Search</ion-button>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-grid>\r\n<ion-refresher slot=\"fixed\"\r\n(ionRefresh)=\"ionRefresh($event)\">\r\n  <ion-refresher-content\r\n    pullingIcon=\"arrow-dropdown\"\r\n    pullingText=\"Tirar para refrescar\"\r\n    refreshingSpinner=\"circles\"\r\n    refreshingText=\"Actualizando...\">\r\n  </ion-refresher-content>\r\n</ion-refresher>\r\n<ion-content>\r\n<ion-list>\r\n<ion-item button *ngFor=\"let user of users\" >\r\n<ion-row>\r\n  <ion-col>\r\n          <ion-label class=\"notification-title\" >Nombre: {{ user.value.username }}&nbsp; &nbsp; <small class=\"date-notification\"><strong>Role: </strong>&nbsp; {{ user.value.role}}</small> </ion-label>\r\n          <p class=\"text-notification\">&nbsp;email: {{ user.value.email }}</p>\r\n  </ion-col>\r\n</ion-row>\r\n</ion-item>\r\n</ion-list>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/pages/admin/users/users.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/admin/users/users.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3VzZXJzL3VzZXJzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/users/users.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/admin/users/users.page.ts ***!
  \*************************************************/
/*! exports provided: UsersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersPage", function() { return UsersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/admin.service */ "./src/app/services/admin.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var UsersPage = /** @class */ (function () {
    function UsersPage(alertController, loadingCtrl, events, adminService) {
        this.alertController = alertController;
        this.loadingCtrl = loadingCtrl;
        this.events = events;
        this.adminService = adminService;
        this.searchuser = '';
        this.onFiltro = false;
    }
    UsersPage.prototype.ngOnInit = function () {
        this.getUsers();
    };
    UsersPage.prototype.getUsers = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando users..',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.adminService.getAllUsersAdmin().then(function (value) {
                            _this.users = value.data.users.entry;
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    UsersPage.prototype.getAllUsersAdminFiltro = function (name, role) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando filtros...',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        name = this.searchuser;
                        this.adminService.getAllUsersAdminFiltro(name, role).then(function (value) {
                            _this.users = value.data.users.entry;
                            _this.tipoSelected = 0;
                            loading.dismiss();
                        }).catch(function (error) {
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    UsersPage.prototype.searchTipoChanged = function () {
        this.onFiltro = true;
        this.tipoSelected = this.type;
        this.getAllUsersAdminFiltro(this.searchuser, this.tipoSelected);
    };
    UsersPage.prototype.ionRefresh = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getUsers()];
                    case 1:
                        _a.sent();
                        event.target.complete();
                        return [2 /*return*/];
                }
            });
        });
    };
    UsersPage.prototype.ionViewDidEnter = function () {
        this.getUsers();
    };
    UsersPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-users',
            template: __webpack_require__(/*! ./users.page.html */ "./src/app/pages/admin/users/users.page.html"),
            styles: [__webpack_require__(/*! ./users.page.scss */ "./src/app/pages/admin/users/users.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"],
            src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_2__["AdminService"]])
    ], UsersPage);
    return UsersPage;
}());



/***/ })

}]);
//# sourceMappingURL=users-users-module.js.map