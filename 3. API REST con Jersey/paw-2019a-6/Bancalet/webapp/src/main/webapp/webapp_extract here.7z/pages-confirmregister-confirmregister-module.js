(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-confirmregister-confirmregister-module"],{

/***/ "./src/app/pages/confirmregister/confirmregister.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/confirmregister/confirmregister.module.ts ***!
  \*****************************************************************/
/*! exports provided: ConfirmregisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfirmregisterPageModule", function() { return ConfirmregisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _confirmregister_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./confirmregister.page */ "./src/app/pages/confirmregister/confirmregister.page.ts");







var routes = [
    {
        path: '',
        component: _confirmregister_page__WEBPACK_IMPORTED_MODULE_6__["ConfirmregisterPage"]
    }
];
var ConfirmregisterPageModule = /** @class */ (function () {
    function ConfirmregisterPageModule() {
    }
    ConfirmregisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_confirmregister_page__WEBPACK_IMPORTED_MODULE_6__["ConfirmregisterPage"]]
        })
    ], ConfirmregisterPageModule);
    return ConfirmregisterPageModule;
}());



/***/ }),

/***/ "./src/app/pages/confirmregister/confirmregister.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/confirmregister/confirmregister.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content  color=\"primary\">\r\n  <ion-header>\r\n    <ion-toolbar>\r\n      <ion-title color=\"primary\" text-center>Confirmacion de registro</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <div text-center>\r\n    <h3>Has activado tu cuenta, ahora ya puedes acceder a ella.</h3>\r\n  </div>\r\n  <div text-center margin-top>\r\n    <span (click)=\"goToLogin()\" tappable>\r\n      <ion-text color=\"light\">\r\n        <strong>Accede a tu cuenta ahora!</strong>\r\n      </ion-text>\r\n    </span>\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/confirmregister/confirmregister.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/confirmregister/confirmregister.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NvbmZpcm1yZWdpc3Rlci9jb25maXJtcmVnaXN0ZXIucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/confirmregister/confirmregister.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/confirmregister/confirmregister.page.ts ***!
  \***************************************************************/
/*! exports provided: ConfirmregisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfirmregisterPage", function() { return ConfirmregisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth/auth.service */ "./src/app/services/auth/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var ConfirmregisterPage = /** @class */ (function () {
    function ConfirmregisterPage(activatedRoute, alertCtrl, authService, loadingCtrl, navCtrl, toastCtrl) {
        this.activatedRoute = activatedRoute;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
    }
    ConfirmregisterPage.prototype.ngOnInit = function () {
        var _this = this;
        var id = this.activatedRoute.snapshot.paramMap.get('id');
        this.authService.confirmregister(id).then(function (value) {
            _this.presentToast('Email verificado correctamente, ahora ya puedes acceder a tu cuenta.');
            _this.navCtrl.navigateRoot('/');
        }).catch(function (error) {
            if (error.toString().includes("Forbidden")) {
                _this.navCtrl.navigateRoot('/');
                _this.presentToast('Ya has verificado tu email.');
            }
            if (error.toString().includes("Ruta Authorization Required")) {
                _this.navCtrl.navigateRoot('/');
                _this.presentToast('Usuario no encontrado.');
            }
            if (error.toString().includes("403")) {
                _this.navCtrl.navigateRoot('/');
                _this.presentToast('Ya has verificado tu email.');
            }
            if (error.toString().includes("404")) {
                _this.navCtrl.navigateRoot('/');
                _this.presentToast('Usuario no encontrado.');
            }
        });
    };
    ConfirmregisterPage.prototype.goToLogin = function () {
        this.navCtrl.navigateRoot('/');
    };
    ConfirmregisterPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 10000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ConfirmregisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-confirmregister',
            template: __webpack_require__(/*! ./confirmregister.page.html */ "./src/app/pages/confirmregister/confirmregister.page.html"),
            styles: [__webpack_require__(/*! ./confirmregister.page.scss */ "./src/app/pages/confirmregister/confirmregister.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], ConfirmregisterPage);
    return ConfirmregisterPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-confirmregister-confirmregister-module.js.map