(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-admin-issue-details-issue-details-module"],{

/***/ "./src/app/pages/admin/issue-details/issue-details.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/admin/issue-details/issue-details.module.ts ***!
  \*******************************************************************/
/*! exports provided: IssueDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IssueDetailsPageModule", function() { return IssueDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _issue_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./issue-details.page */ "./src/app/pages/admin/issue-details/issue-details.page.ts");







var routes = [
    {
        path: '',
        component: _issue_details_page__WEBPACK_IMPORTED_MODULE_6__["IssueDetailsPage"]
    }
];
var IssueDetailsPageModule = /** @class */ (function () {
    function IssueDetailsPageModule() {
    }
    IssueDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_issue_details_page__WEBPACK_IMPORTED_MODULE_6__["IssueDetailsPage"]]
        })
    ], IssueDetailsPageModule);
    return IssueDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/admin/issue-details/issue-details.page.html":
/*!*******************************************************************!*\
  !*** ./src/app/pages/admin/issue-details/issue-details.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Consulta de {{ issue.name }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <ion-card *ngIf=\"issue\">\r\n      <ion-item lines=\"none\">\r\n          <h2>Asunto: {{ issue.asunto }}</h2>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n        <ion-note>\r\n            Contactado el {{ issue.fechaContacto }}\r\n        </ion-note>\r\n      </ion-item>\r\n    <ion-card-content text-center>\r\n      <ion-item lines=\"none\">\r\n        <ion-label>Mensaje: {{ issue.mensaje }}</ion-label>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-label>Email: {{ issue.email }}</ion-label>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\" *ngIf=\"issue.estado==0\">\r\n        <ion-label>Informe: {{ issue.informe }}</ion-label>\r\n    </ion-item>\r\n\r\n      <ion-item lines=\"none\" *ngIf=\"issue.estado==0\">\r\n          <i class=\" material-icons\">help_outline</i>\r\n          <ion-label>Estado: <i class=\" material-icons\">check_circle</i></ion-label>\r\n      </ion-item>\r\n      <ion-item lines=\"none\" *ngIf=\"issue.estado==1\">\r\n          <i class=\" material-icons\">help_outline</i>\r\n          <ion-label >Estado: <i class=\" material-icons\">check_circle</i></ion-label>\r\n      </ion-item>\r\n        <ion-button shape=\"round\" *ngIf=\"issue.estado==1\" (click)=\"onArchivar()\" fill=\"outline\" color=\"secondary\"> <ion-icon slot=\"mail\" name=\"star\"></ion-icon>Archivar</ion-button>\r\n        <ion-button shape=\"round\" *ngIf=\"issue.estado==1\" (click)=\"onDeleteIssue()\" fill=\"outline\" color=\"danger\"> <ion-icon slot=\"mail\" name=\"star\"></ion-icon>Eliminar</ion-button>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/pages/admin/issue-details/issue-details.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/admin/issue-details/issue-details.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".card-subtitle {\n  font-size: 1.0em;\n  position: absolute;\n  top: 52%;\n  width: 100%;\n  color: #fff; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW4vaXNzdWUtZGV0YWlscy9DOlxcaXRiYVxcd3NcXHBhdy0yMDE5YS02XFxCYW5jYWxldFxcd2ViYXBwXFxyZXN0Y2xpZW50L3NyY1xcYXBwXFxwYWdlc1xcYWRtaW5cXGlzc3VlLWRldGFpbHNcXGlzc3VlLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsV0FBVztFQUNYLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL2lzc3VlLWRldGFpbHMvaXNzdWUtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZC1zdWJ0aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDEuMGVtO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MiU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/pages/admin/issue-details/issue-details.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/admin/issue-details/issue-details.page.ts ***!
  \*****************************************************************/
/*! exports provided: IssueDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IssueDetailsPage", function() { return IssueDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/admin.service */ "./src/app/services/admin.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var IssueDetailsPage = /** @class */ (function () {
    function IssueDetailsPage(activatedRoute, navCtrl, alertCtrl, loadingCtrl, adminService, toastCtrl) {
        this.activatedRoute = activatedRoute;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.adminService = adminService;
        this.toastCtrl = toastCtrl;
    }
    IssueDetailsPage.prototype.ngOnInit = function () {
        var id = this.activatedRoute.snapshot.paramMap.get('id');
        this.issueID = id;
        this.getIssueID(id);
    };
    IssueDetailsPage.prototype.getIssueID = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando issue..',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.adminService.getIssuesID(id).then(function (value) {
                            _this.issue = value.data.issue;
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    IssueDetailsPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 4000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    IssueDetailsPage.prototype.onDeleteIssue = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: ' ¿Desea eliminar la consulta? ',
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                }, {
                                    text: 'Confirmar',
                                    handler: function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                        var loading;
                                        var _this = this;
                                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                            switch (_a.label) {
                                                case 0: return [4 /*yield*/, this.loadingCtrl.create({
                                                        message: 'Eliminando consulta.. ',
                                                        translucent: true,
                                                    })];
                                                case 1:
                                                    loading = _a.sent();
                                                    return [4 /*yield*/, loading.present()];
                                                case 2:
                                                    _a.sent();
                                                    this.adminService.delete(this.issueID).then(function (value) {
                                                        loading.dismiss();
                                                        _this.presentToast('Consulta eliminada');
                                                        _this.navCtrl.navigateRoot('/tabs-admin');
                                                    }).catch(function (error) {
                                                        if (!error.response) {
                                                            error.response = 'ERROR';
                                                        }
                                                        loading.dismiss();
                                                        _this.presentToast('Error al eliminar la consulta');
                                                        _this.navCtrl.navigateRoot('/tabs-admin');
                                                    });
                                                    return [2 /*return*/];
                                            }
                                        });
                                    }); }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    IssueDetailsPage.prototype.onArchivar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: 'Responder a ' + this.issue.name,
                            message: 'Escribe el informe',
                            inputs: [
                                {
                                    name: 'informe',
                                    type: 'text',
                                    placeholder: 'Informe'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                }, {
                                    text: 'Confirmar',
                                    handler: function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                        var loading, adminForm;
                                        var _this = this;
                                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                            switch (_a.label) {
                                                case 0: return [4 /*yield*/, this.loadingCtrl.create({
                                                        message: 'Enviando mensaje.. ',
                                                        translucent: true,
                                                    })];
                                                case 1:
                                                    loading = _a.sent();
                                                    return [4 /*yield*/, loading.present()];
                                                case 2:
                                                    _a.sent();
                                                    adminForm = {
                                                        informe: data.informe
                                                    };
                                                    this.adminService.archive(adminForm, this.issueID).then(function (value) {
                                                        loading.dismiss();
                                                        _this.presentToast(value.data.mensaje);
                                                        _this.navCtrl.navigateRoot('/tabs-admin');
                                                    }).catch(function (error) {
                                                        if (!error.response) {
                                                            error.response = 'ERROR';
                                                        }
                                                        loading.dismiss();
                                                        _this.navCtrl.navigateRoot('/tabs-admin');
                                                        _this.presentToast('Error al enviar el informe');
                                                    });
                                                    return [2 /*return*/];
                                            }
                                        });
                                    }); }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    IssueDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-issue-details',
            template: __webpack_require__(/*! ./issue-details.page.html */ "./src/app/pages/admin/issue-details/issue-details.page.html"),
            styles: [__webpack_require__(/*! ./issue-details.page.scss */ "./src/app/pages/admin/issue-details/issue-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], src_app_services_admin_service__WEBPACK_IMPORTED_MODULE_3__["AdminService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]])
    ], IssueDetailsPage);
    return IssueDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-admin-issue-details-issue-details-module.js.map