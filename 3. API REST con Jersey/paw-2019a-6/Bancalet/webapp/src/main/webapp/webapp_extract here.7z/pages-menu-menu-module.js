(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-menu-menu-module"],{

/***/ "./src/app/pages/menu/menu.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/menu/menu.module.ts ***!
  \*******************************************/
/*! exports provided: MenuPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuPageModule", function() { return MenuPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _menu_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./menu.page */ "./src/app/pages/menu/menu.page.ts");







var routes = [
    {
        path: '',
        redirectTo: 'first',
        pathMatch: 'full'
    },
    {
        path: '',
        component: _menu_page__WEBPACK_IMPORTED_MODULE_6__["MenuPage"],
        children: [
            {
                path: 'first',
                loadChildren: '../first-tab/first-tab.module#FirstTabPageModule'
            },
            {
                path: 'misrecomendaciones',
                loadChildren: '../user/misrecomendaciones/misrecomendaciones.module#MisrecomendacionesPageModule'
            },
            {
                path: 'mismensajes',
                loadChildren: '../user/mismensajes/mismensajes.module#MismensajesPageModule'
            },
            {
                path: 'miscontactados',
                loadChildren: '../user/miscontactados/miscontactados.module#MiscontactadosPageModule'
            },
            {
                path: 'ayuda',
                loadChildren: '../user/ayuda/ayuda.module#AyudaPageModule'
            }
        ]
    }
];
var MenuPageModule = /** @class */ (function () {
    function MenuPageModule() {
    }
    MenuPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_menu_page__WEBPACK_IMPORTED_MODULE_6__["MenuPage"]]
        })
    ], MenuPageModule);
    return MenuPageModule;
}());



/***/ }),

/***/ "./src/app/pages/menu/menu.page.html":
/*!*******************************************!*\
  !*** ./src/app/pages/menu/menu.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n    <ion-split-pane>\r\n<ion-menu contentId=\"content\">\r\n  <ion-toolbar color=\"dark\" class=\"user-profile\">\r\n\r\n    <ion-item margin-bottom>\r\n      <ion-avatar slot=\"start\" class=\"user-avatar\">\r\n        <img src=\"assets/img/avatar/avatar{{ currentUser.numImg }}.png\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <ion-text color=\"medium\">\r\n          <h1><strong>{{ currentUser.username }}</strong></h1>\r\n        </ion-text>\r\n        <ion-text color=\"secondary\">\r\n          <h3>\r\n            {{ currentUser.email }}\r\n          </h3>\r\n        </ion-text>\r\n        <ion-menu-toggle class=\"mto\" auto-hide=\"false\">\r\n          <a class=\"text08\" tappable [routerLink]=\"['/', 'user', currentUserId]\">\r\n            <ion-text color=\"medium\">\r\n              <strong>Ver perfil</strong>\r\n            </ion-text>\r\n          </a> <ion-text color=\"secondary\"> | </ion-text> \r\n          <a class=\"text08\" tappable (click)=\"logout()\">\r\n            <ion-text color=\"medium\">\r\n              <ion-icon name=\"log-out\"></ion-icon>\r\n              <strong>Logout</strong>\r\n            </ion-text>\r\n          </a>\r\n        </ion-menu-toggle>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n  </ion-toolbar>\r\n<ion-content class=\"bg-profile\">\r\n    <ion-list-header color=\"dark\">\r\n        <ion-label>Menu</ion-label>\r\n      </ion-list-header>\r\n  <div *ngFor=\"let p of pages\">\r\n      \r\n    <!-- Standard Menu Item -->\r\n    <ion-menu-toggle *ngIf=\"p.url\" auto-hide=\"false\">\r\n      <ion-item [routerLink]=\"p.url\" routerDirection=\"root\" routerLinkActive=\"active\" color=\"primary\">\r\n        <i class=\" material-icons\">{{p.icon}}</i> &nbsp;\r\n        <ion-label>\r\n          {{ p.title }}\r\n        </ion-label>\r\n        <ion-note slot=\"end\"></ion-note>\r\n      </ion-item>\r\n    </ion-menu-toggle>\r\n    <!-- Item with Children -->\r\n\r\n    <ion-item button *ngIf=\"p.children?.length > 0\" (click)=\"p.open = !p.open\" [class.parent-active]=\"p.open\" detail=\"false\" color=\"primary\">\r\n      <ion-icon slot=\"start\" name=\"arrow-forward\" *ngIf=\"!p.open\"></ion-icon>\r\n      <ion-icon slot=\"start\" name=\"arrow-down\" *ngIf=\"p.open\"></ion-icon>\r\n      <ion-label>{{ p.title }}</ion-label>\r\n    </ion-item>\r\n\r\n    <!-- Children List for clicked Item -->\r\n    <ion-list *ngIf=\"p.open\"  class=\"ion-menu-parent\">\r\n      <ion-menu-toggle auto-hide=\"false\">\r\n        <ion-item *ngFor=\"let sub of p.children\" class=\"sub-item\" [routerLink]=\"sub.url\" routerDirection=\"root\"\r\n          routerLinkActive=\"active\" >\r\n          <ion-icon [name]=\"sub.icon\" slot=\"start\" color=\"light\"></ion-icon>\r\n          <ion-label>\r\n            {{ sub.title }}\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-menu-toggle>\r\n    </ion-list>\r\n\r\n  </div>\r\n</ion-content>\r\n\r\n</ion-menu>\r\n\r\n<ion-router-outlet id=\"content\" main></ion-router-outlet>\r\n</ion-split-pane>\r\n</ion-app>\r\n"

/***/ }),

/***/ "./src/app/pages/menu/menu.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/menu/menu.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".active {\n  --ion-text-color: var(--ion-color-primary); }\n  .active ion-icon {\n    --ion-text-color-rgb: var(--ion-color-primary); }\n  .parent-active {\n  font-weight: 500; }\n  .sub-item {\n  font-size: small;\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n  .active-item {\n  border-left: 8px solid var(--ion-color-secondary); }\n  .ion-menu-parent {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n  :host ion-content {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n  :host ion-list.list-md {\n  padding: 0; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbWVudS9DOlxcaXRiYVxcd3NcXHBhdy0yMDE5YS02XFxCYW5jYWxldFxcd2ViYXBwXFxyZXN0Y2xpZW50L3NyY1xcYXBwXFxwYWdlc1xcbWVudVxcbWVudS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSwwQ0FBaUIsRUFBQTtFQURyQjtJQUlRLDhDQUFxQixFQUFBO0VBSTdCO0VBQ0ksZ0JBQWdCLEVBQUE7RUFHcEI7RUFFSSxnQkFBZ0I7RUFDaEIsc0ZBQWEsRUFBQTtFQUdqQjtFQUNJLGlEQUFrRCxFQUFBO0VBRXREO0VBRUEsc0ZBQWEsRUFBQTtFQUViO0VBRVEsc0ZBQWEsRUFBQTtFQUZyQjtFQU9ZLFVBQVUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21lbnUvbWVudS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLmFjdGl2ZSB7XHJcbiAgICAtLWlvbi10ZXh0LWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiBcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgICAtLWlvbi10ZXh0LWNvbG9yLXJnYjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgfVxyXG59XHJcbiBcclxuLnBhcmVudC1hY3RpdmUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG4gXHJcbi5zdWItaXRlbSB7XHJcbiAgICBcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcclxuICAgIFxyXG59XHJcbi5hY3RpdmUtaXRlbSB7XHJcbiAgICBib3JkZXItbGVmdDogOHB4IHNvbGlkIHZhciggLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcclxufVxyXG4uaW9uLW1lbnUtcGFyZW50ICB7XHJcblxyXG4tLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcclxufVxyXG46aG9zdCB7XHJcbiAgICBpb24tY29udGVudCB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICAgICYubGlzdC1tZCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/menu/menu.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/menu/menu.page.ts ***!
  \*****************************************/
/*! exports provided: MenuPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuPage", function() { return MenuPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/auth/auth.service */ "./src/app/services/auth/auth.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/settings */ "./src/app/providers/settings.ts");







var MenuPage = /** @class */ (function () {
    function MenuPage(usersService, authService, navCtrl, router, settings) {
        var _this = this;
        this.usersService = usersService;
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.router = router;
        this.settings = settings;
        this.selectedPath = '';
        this.pages = [
            {
                title: 'Anuncios',
                url: '/menu/first',
                icon: 'store'
            },
            {
                title: 'Mis Recomendaciones',
                url: '/menu/misrecomendaciones',
                icon: 'favorite'
            },
            {
                title: 'Mis Enviados',
                url: '/menu/miscontactados',
                icon: 'mail'
            },
            {
                title: 'Mensajes Recibidos',
                url: '/menu/mismensajes',
                icon: 'inbox'
            },
            {
                title: 'Ayuda',
                url: '/menu/ayuda',
                icon: 'live_help'
            }
        ];
        this.router.events.subscribe(function (event) {
            if (event && event.url) {
                _this.selectedPath = event.url;
            }
        });
    }
    MenuPage.prototype.ngOnInit = function () {
        var _this = this;
        this.currentUser = this.usersService.getUserInfo();
        this.currentUserId = this.usersService.getIdUserInfo();
        this.usersService.getUserPrincipal().then(function (data) {
            _this.currentUser = data;
            console.log('currentUser', _this.currentUser);
            _this.currentUserId = _this.usersService.getIdUserInfo();
        });
    };
    MenuPage.prototype.ionViewWillEnter = function () {
    };
    MenuPage.prototype.logout = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.navCtrl.navigateRoot('/');
                        return [4 /*yield*/, this.settings.remove('AuthToken')];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.settings.remove('user')];
                    case 2:
                        _a.sent();
                        this.authService.authState.next(false);
                        return [2 /*return*/];
                }
            });
        });
    };
    MenuPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__(/*! ./menu.page.html */ "./src/app/pages/menu/menu.page.html"),
            styles: [__webpack_require__(/*! ./menu.page.scss */ "./src/app/pages/menu/menu.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_users_service__WEBPACK_IMPORTED_MODULE_3__["UsersService"], _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], src_app_providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], MenuPage);
    return MenuPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-menu-menu-module.js.map