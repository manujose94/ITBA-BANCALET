(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-miscontactados-miscontactados-module"],{

/***/ "./src/app/pages/user/miscontactados/miscontactados.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/user/miscontactados/miscontactados.module.ts ***!
  \********************************************************************/
/*! exports provided: MiscontactadosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MiscontactadosPageModule", function() { return MiscontactadosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _miscontactados_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./miscontactados.page */ "./src/app/pages/user/miscontactados/miscontactados.page.ts");







var routes = [
    {
        path: '',
        component: _miscontactados_page__WEBPACK_IMPORTED_MODULE_6__["MiscontactadosPage"]
    }
];
var MiscontactadosPageModule = /** @class */ (function () {
    function MiscontactadosPageModule() {
    }
    MiscontactadosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_miscontactados_page__WEBPACK_IMPORTED_MODULE_6__["MiscontactadosPage"]]
        })
    ], MiscontactadosPageModule);
    return MiscontactadosPageModule;
}());



/***/ }),

/***/ "./src/app/pages/user/miscontactados/miscontactados.page.html":
/*!********************************************************************!*\
  !*** ./src/app/pages/user/miscontactados/miscontactados.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Mensajes Enviados</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n  <ion-content>\r\n      <ion-refresher slot=\"fixed\" \r\n      (ionRefresh)=\"ionRefresh($event)\" \r\n     >\r\n        <ion-refresher-content\r\n          pullingIcon=\"arrow-dropdown\"\r\n          pullingText=\"Tirar para refrescar\"\r\n          refreshingSpinner=\"circles\"\r\n          refreshingText=\"Actualizando...\">\r\n        </ion-refresher-content>\r\n      </ion-refresher>\r\n\r\n    <ion-content>\r\n        <ion-label *ngIf=\"!enviados\">\r\n            <h1>No hay mensajes enviados</h1>\r\n          </ion-label>\r\n  <ion-list>   \r\n    <ion-card button *ngFor=\"let contacto of contactos\"  lines=\"none\" >\r\n\r\n      \r\n      <ion-card-header class=\"header\">\r\n        <ion-card-subtitle>Fecha del mensaje: {{contacto.value.fechaContacto}}</ion-card-subtitle>\r\n        <ion-card-title>{{contacto.value.mensaje}}</ion-card-title>\r\n      </ion-card-header>\r\n      <div *ngFor=\"let item of items\">\r\n          <li *ngIf=\"item.key==contacto.value.itemId\" >\r\n      <ion-card-content > \r\n        <ion-item lines=\"none\">\r\n          <ion-avatar>\r\n            <img src=\"assets/img/type_food/{{item.value.tipo}}.png\">\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <h2>{{ item.value.name }}</h2>\r\n          </ion-label>\r\n        </ion-item>\r\n        <ion-row>\r\n          <ion-col>\r\n\r\n            <ion-label>\r\n              <i class=\" material-icons\">subject</i>&nbsp;Descripcion: {{ item.value.description }}&nbsp;\r\n              &nbsp;&nbsp; <p></p><small class=\"date-notification\"><i class=\" material-icons\">monetization_on</i>&nbsp;Publicado: {{ item.value.fechaPublicacion }}</small>\r\n            </ion-label>\r\n            <p></p>\r\n            <ion-label>\r\n                <i class=\" material-icons\">monetization_on</i>&nbsp;Precio: {{ item.value.price}}\r\n            </ion-label>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-card-content>\r\n    </li>\r\n  </div>\r\n    </ion-card>\r\n    \r\n   \r\n      \r\n      </ion-list>\r\n   \r\n  </ion-content>"

/***/ }),

/***/ "./src/app/pages/user/miscontactados/miscontactados.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/pages/user/miscontactados/miscontactados.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background-color: thistle; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlci9taXNjb250YWN0YWRvcy9DOlxcaXRiYVxcd3NcXHBhdy0yMDE5YS02XFxCYW5jYWxldFxcd2ViYXBwXFxyZXN0Y2xpZW50L3NyY1xcYXBwXFxwYWdlc1xcdXNlclxcbWlzY29udGFjdGFkb3NcXG1pc2NvbnRhY3RhZG9zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUNKLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy91c2VyL21pc2NvbnRhY3RhZG9zL21pc2NvbnRhY3RhZG9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdGhpc3RsZVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/user/miscontactados/miscontactados.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/user/miscontactados/miscontactados.page.ts ***!
  \******************************************************************/
/*! exports provided: MiscontactadosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MiscontactadosPage", function() { return MiscontactadosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var MiscontactadosPage = /** @class */ (function () {
    function MiscontactadosPage(alertController, loadingCtrl, usersService) {
        this.alertController = alertController;
        this.loadingCtrl = loadingCtrl;
        this.usersService = usersService;
        this.enviados = true;
    }
    MiscontactadosPage.prototype.ngOnInit = function () {
        this.getMisMensajesEnviados();
    };
    MiscontactadosPage.prototype.getMisMensajesEnviados = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando mensajes..',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.usersService.getMisMensajesEnviados().then(function (value) {
                            _this.items = value.data.items.entry;
                            _this.contactos = value.data.contactos.entry;
                            _this.sellers = value.data.listcontactados.entry;
                            if (_this.contactos.length === 0) {
                                _this.enviados = false;
                            }
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    MiscontactadosPage.prototype.ionRefresh = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getMisMensajesEnviados()];
                    case 1:
                        _a.sent();
                        event.target.complete();
                        return [2 /*return*/];
                }
            });
        });
    };
    MiscontactadosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-miscontactados',
            template: __webpack_require__(/*! ./miscontactados.page.html */ "./src/app/pages/user/miscontactados/miscontactados.page.html"),
            styles: [__webpack_require__(/*! ./miscontactados.page.scss */ "./src/app/pages/user/miscontactados/miscontactados.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], src_app_services_users_service__WEBPACK_IMPORTED_MODULE_2__["UsersService"]])
    ], MiscontactadosPage);
    return MiscontactadosPage;
}());



/***/ }),

/***/ "./src/app/services/users.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/users.service.ts ***!
  \*******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_RestClient__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/RestClient */ "./src/app/services/api/RestClient.ts");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../providers/settings */ "./src/app/providers/settings.ts");







var UsersService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UsersService, _super);
    function UsersService(http, settings) {
        var _this = _super.call(this, null) || this;
        _this.http = http;
        _this.settings = settings;
        _this.url2 = './../assets/data/countrys.json';
        settings.getValue('AuthToken').then(function (value) {
            _this.token = value;
            return value;
        });
        return _this;
    }
    UsersService.prototype.getUserInfo = function () {
        return this.currentUser;
    };
    UsersService.prototype.getUserPrincipal = function () {
        var _this = this;
        if (this.currentUser) {
            return this.currentUser;
        }
        else {
            return new Promise(function (resolve) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.settings.load().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                var _this = this;
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.getUserUsername(this.settings.allSettings.user.username).then(function (response) {
                                                _this.currentUserId = response.data.id;
                                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                                _this.currentUser = response.data.user;
                                            }).catch(function (error) {
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            }); })];
                        case 1:
                            _a.sent();
                            resolve(this.currentUser);
                            return [2 /*return*/];
                    }
                });
            }); });
        }
    };
    UsersService.prototype.getIdUserInfo = function () {
        return this.currentUserId;
    };
    UsersService.prototype.getCountrys = function () {
        var _this = this;
        return new Promise(function (resolve) {
            _this.http.get(_this.url2).
                pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (response) { return response; })).
                subscribe(function (data) {
                {
                    _this.countrys = data;
                    resolve(_this.countrys);
                }
            });
        });
    };
    UsersService.prototype.getUserId = function (id) {
        return this.instance.get('rest/users/' + id);
    };
    UsersService.prototype.getUserUsername = function (username) {
        this.init();
        return this.instance.get('rest/users/login/' + username);
    };
    UsersService.prototype.getUsersDTO = function () {
        return this.instance.get('rest/users');
    };
    UsersService.prototype.getHistorialCompra = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscompras');
    };
    UsersService.prototype.getHistorialVentas = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/misventas');
    };
    UsersService.prototype.getMisSugerencias = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('/rest/users/missugerencias');
    };
    UsersService.prototype.getMisMensajesEnviados = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactose');
    };
    UsersService.prototype.getMisMensajesRecibidos = function () {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.get('rest/users/miscontactosr');
    };
    UsersService.prototype.getMaxVendor = function (id) {
        return this.instance.get('rest/users/getMaxVendor/' + id);
    };
    UsersService.prototype.getMaxBuyer = function (id) {
        return this.instance.get('rest/users/getMaxBuyer/' + id);
    };
    UsersService.prototype.getMaxRated = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.getRate = function (id) {
        return this.instance.get('rest/users/getMaxRated/' + id);
    };
    UsersService.prototype.contactarAdminlogin = function (contactForm) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json', 'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.post('rest/users/help', contactForm);
    };
    UsersService.prototype.updatepass = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/editPass/', user);
    };
    UsersService.prototype.update = function (user) {
        this.instance = axios__WEBPACK_IMPORTED_MODULE_5___default.a.create({
            baseURL: "" + this.protocol + this.domain + this.port + this.root,
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json',
                'X-AUTH-TOKEN': this.token
            }
        });
        return this.instance.put('rest/users/edit/', user);
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _providers_settings__WEBPACK_IMPORTED_MODULE_6__["SettingsProvider"]])
    ], UsersService);
    return UsersService;
}(_api_RestClient__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ })

}]);
//# sourceMappingURL=user-miscontactados-miscontactados-module.js.map