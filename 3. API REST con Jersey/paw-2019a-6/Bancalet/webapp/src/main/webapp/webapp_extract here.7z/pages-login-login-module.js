(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "./src/app/pages/login/login.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");








var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/pages/login/login.page.html":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding class=\"animated fadeIn login auth-page\">\r\n  <div class=\"theme-bg\"></div>\r\n  <div class=\"auth-content\">\r\n\r\n    <!-- Logo -->\r\n    <div padding-horizontal text-center class=\"animated fadeInDown\">\r\n      <!-- <div class=\"logo\"></div>-->\r\n      <ion-avatar class=\"logo\">\r\n          <img src=\"assets/img/appicon.png\">\r\n        </ion-avatar>\r\n      <h4 no-margin>\r\n        <ion-text color=\"light\" class=\"fw700\">\r\n          Bancalet\r\n        </ion-text>\r\n      </h4>\r\n    </div>\r\n\r\n    <!-- Login form -->\r\n    <form [formGroup]=\"onLoginForm\" class=\"list-form\">\r\n      <ion-item no-padding class=\"animated fadeInUp\">\r\n        <ion-label position=\"floating\">\r\n            <i class=\"material-icons\">mail</i>\r\n          Email/Name\r\n        </ion-label>\r\n        <ion-input color=\"secondary\" type=\"email\" formControlName=\"username\" [(ngModel)]=\"registerCredentials.username\" required></ion-input>\r\n      </ion-item>\r\n      <p ion-text class=\"text08\" *ngIf=\"onLoginForm.get('username').touched && onLoginForm.get('username').hasError('required')\">\r\n        <ion-text color=\"warning\">\r\n          Required Field\r\n        </ion-text>\r\n      </p>\r\n\r\n      <ion-item no-padding class=\"animated fadeInUp\">\r\n        <ion-label position=\"floating\">\r\n            <i class=\"material-icons\">enhanced_encryption</i>\r\n          Password\r\n        </ion-label>\r\n        <ion-input color=\"secondary\" type=\"password\" formControlName=\"password\" [(ngModel)]=\"registerCredentials.password\" required></ion-input>\r\n      </ion-item>\r\n      <p ion-text color=\"warning\" class=\"text08\" *ngIf=\"onLoginForm.get('password').touched && onLoginForm.get('password').hasError('required')\">\r\n        <ion-text color=\"warning\">\r\n          Required Field\r\n        </ion-text>\r\n        </p>\r\n    </form>\r\n\r\n    <p text-right tappable (click)=\"forgotPass()\" class=\"paz\">\r\n      <ion-text color=\"light\">\r\n        <strong>¿Necesitas ayuda?</strong>\r\n      </ion-text>\r\n    </p>\r\n\r\n    <div>\r\n      <ion-button icon-left size=\"medium\" expand=\"full\" shape=\"round\" color=\"dark\" (click)=\"goToHome()\" [disabled]=\"!onLoginForm.valid\" tappable>\r\n          <i class=\"material-icons\">input</i>\r\n        &nbsp; Ingresar\r\n      </ion-button>\r\n\r\n    \r\n\r\n    </div>\r\n\r\n    <!-- Other links -->\r\n    <div text-center margin-top>\r\n      <span (click)=\"goToRegister()\" class=\"paz\" tappable>\r\n        <ion-text color=\"light\">\r\n          Nuevo? <strong>Registrate</strong>\r\n        </ion-text>\r\n      </span>\r\n    </div>\r\n\r\n\r\n\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-content {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n.paz {\n  position: relative;\n  z-index: 10; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4vQzpcXGl0YmFcXHdzXFxwYXctMjAxOWEtNlxcQmFuY2FsZXRcXHdlYmFwcFxccmVzdGNsaWVudC9zcmNcXGFwcFxccGFnZXNcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFUSxzRkFBYSxFQUFBOztBQUlyQjtFQUNJLGtCQUFrQjtFQUNsQixXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgICBpb24tY29udGVudCB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wYXoge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgei1pbmRleDogMTA7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_providers_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/providers/settings */ "./src/app/providers/settings.ts");
/* harmony import */ var src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/auth/auth.service */ "./src/app/services/auth/auth.service.ts");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");







var LoginPage = /** @class */ (function () {
    function LoginPage(alertController, navCtrl, menuCtrl, toastCtrl, alertCtrl, loadingCtrl, formBuilder, authService, usersService, settings) {
        this.alertController = alertController;
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.formBuilder = formBuilder;
        this.authService = authService;
        this.usersService = usersService;
        this.settings = settings;
        this.registerCredentials = { username: '', password: '' };
    }
    LoginPage.prototype.ionViewWillEnter = function () {
        this.menuCtrl.enable(false);
    };
    LoginPage.prototype.ngOnInit = function () {
        this.settings.load().then(function () {
        });
        this.onLoginForm = this.formBuilder.group({
            'username': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
                ])],
            'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
                ])]
        });
    };
    LoginPage.prototype.forgotPass = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: '¿Necesitas ayuda?',
                            message: 'Contacta con nosotros.',
                            inputs: [
                                {
                                    name: 'name',
                                    type: 'text',
                                    placeholder: 'Nombre'
                                },
                                {
                                    name: 'email',
                                    type: 'email',
                                    placeholder: 'Email'
                                }, {
                                    name: 'subject',
                                    type: 'text',
                                    placeholder: 'Asunto'
                                }, {
                                    name: 'mensaje',
                                    type: 'text',
                                    placeholder: 'Mensaje'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                }, {
                                    text: 'Confirm',
                                    handler: function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                        var loading;
                                        var _this = this;
                                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                            switch (_a.label) {
                                                case 0:
                                                    this.contactForm = {
                                                        name: data.name,
                                                        email: data.email,
                                                        subject: data.subject,
                                                        mensaje: data.mensaje,
                                                    };
                                                    return [4 /*yield*/, this.loadingCtrl.create({
                                                            duration: 2000
                                                        })];
                                                case 1:
                                                    loading = _a.sent();
                                                    loading.present();
                                                    this.authService.contactAdmin(this.contactForm).then(function (value) {
                                                        _this.presentToast(value.data.mensaje);
                                                    }).catch(function (error) {
                                                        loading.dismiss();
                                                        if (error.toString().includes("403")) { //forbidden no debes estar logeado para crear usuarios
                                                            _this.presentToast('Ha surgido un problema: Los usuarios logeados no pueden contactar desde esta página.');
                                                        }
                                                        if (error.toString().includes("400")) { //badrequest el formulario tiene eroores
                                                            _this.presentToast('Ha surgido un problema: Faltan datos en el formulario o estan vacíos.');
                                                        }
                                                    });
                                                    return [2 /*return*/];
                                            }
                                        });
                                    }); }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 10000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToRegister = function () {
        this.navCtrl.navigateRoot('register');
    };
    LoginPage.prototype.goToHome = function () {
        var _this = this;
        this.settings.load().then(function () {
            var AuthToken = _this.settings.allSettings.AuthToken;
            _this.authService.loginDTO(_this.onLoginForm.value.username, _this.onLoginForm.value.password)
                .then(function (value) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                var _this = this;
                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.authService.signIn(value.headers['x-auth-token'])];
                        case 1:
                            _a.sent();
                            this.usersService.getUserUsername(this.onLoginForm.value.username).then(function (response) {
                                _this.usersService.currentUser = response.data.user;
                                _this.usersService.currentUserId = response.data.id;
                                _this.settings.storeUserInfo(response.data.user, response.data.id);
                                if (response.data.user.role === 'ADMIN') {
                                    _this.navCtrl.navigateRoot('/tabs-admin');
                                }
                                else {
                                    _this.navCtrl.navigateRoot('/menu');
                                }
                            }).catch(function (error) {
                                _this.presentToast('Credenciales incorrectas.');
                            });
                            return [2 /*return*/];
                    }
                });
            }); }).catch(function (error) {
                _this.presentToast('Credenciales incorrectas.');
            });
        });
    };
    LoginPage.prototype.showError = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Alert',
                            subHeader: 'Subtitle',
                            message: text,
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/pages/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"],
            src_app_services_users_service__WEBPACK_IMPORTED_MODULE_6__["UsersService"],
            src_app_providers_settings__WEBPACK_IMPORTED_MODULE_4__["SettingsProvider"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module.js.map