(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-register-register-module"],{

/***/ "./src/app/pages/register/register.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.module.ts ***!
  \***************************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/pages/register/register.page.ts");







var routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]
    }
];
var RegisterPageModule = /** @class */ (function () {
    function RegisterPageModule() {
    }
    RegisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
        })
    ], RegisterPageModule);
    return RegisterPageModule;
}());



/***/ }),

/***/ "./src/app/pages/register/register.page.html":
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content  color=\"primary\">\r\n  <form  [formGroup]=\"onRegisterForm\">\r\n    <ion-grid>\r\n      <ion-row color=\"primary\" justify-content-center>\r\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\r\n          <div text-center>\r\n            <h3>Registrarse</h3>\r\n          </div>\r\n          <div padding>\r\n              <ion-item>\r\n                  <ion-label>Avatar</ion-label>\r\n                  <ion-avatar>\r\n                    <img src=\"assets/img/avatar/avatar{{avatarId}}.png\">\r\n                  </ion-avatar>\r\n                  <ion-select #S placeholder=\"Seleccionar Avatar\"  (ionChange)=\"onChangeAvatar(S.value)\">\r\n                      <ion-select-option   *ngFor=\"let id of avatar_list\" value=\"{{ id }}\"  >\r\n                        Avatar {{ id }}                   \r\n                      </ion-select-option>\r\n                  </ion-select>\r\n                </ion-item>\r\n            <ion-item>\r\n              <ion-input  name=\"username\" formControlName=\"username\" type=\"text\" placeholder=\"Nombre de usuario\"  required></ion-input>\r\n            </ion-item>\r\n            \r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.username\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('username').hasError(validation.type) && (onRegisterForm.get('username').dirty || onRegisterForm.get('username').touched)\">\r\n                  <ion-text color=\"warning\">\r\n                  {{ validation.message }}\r\n                </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input name=\"email\" formControlName=\"email\" type=\"email\" placeholder=\"ejemplo@email.com\" clearInput  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.email\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('email').hasError(validation.type) && (onRegisterForm.get('email').dirty || onRegisterForm.get('email').touched)\">\r\n                  <ion-text color=\"warning\">\r\n                  {{ validation.message }}\r\n                </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input name=\"password\"  formControlName=\"password\" type=\"password\" placeholder=\"Contraseña\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.password\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('password').hasError(validation.type) && (onRegisterForm.get('password').dirty || onRegisterForm.get('password').touched)\">\r\n                  <ion-text color=\"warning\">\r\n                  {{ validation.message }}\r\n                </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input name=\"confirmPassword\"  formControlName=\"confirmPassword\" type=\"password\" placeholder=\"Repetir contraseña\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.confirmPassword\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('confirmPassword').hasError(validation.type) && (onRegisterForm.get('confirmPassword').dirty || onRegisterForm.get('confirmPassword').touched)\">\r\n                    <ion-text color=\"warning\">\r\n                      {{ validation.message }}\r\n                    </ion-text>\r\n                  </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input  name=\"city\"  formControlName=\"city\"  type=\"text\" placeholder=\"Ciudad\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.city\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('city').touched && onRegisterForm.get('city').hasError('required')\">\r\n                  <ion-text color=\"warning\">\r\n                    {{ validation.message }}\r\n                  </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>        \r\n            <ion-item>\r\n              <ion-input  name=\"direccion\" formControlName=\"direccion\" type=\"text\" placeholder=\"Direccion\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.direccion\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('direccion').touched && onRegisterForm.get('direccion').hasError('direccion')\">\r\n                  <ion-text color=\"warning\">\r\n                    {{ validation.message }}\r\n                  </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input  name=\"code\" formControlName=\"code\" type=\"text\" placeholder=\"Codigo\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.code\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('code').touched && onRegisterForm.get('code').hasError('code')\">\r\n                  <ion-text color=\"warning\">\r\n                    {{ validation.message }}\r\n                  </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n              <ion-input  name=\"telf\" formControlName=\"telf\" type=\"text\" placeholder=\"Telefono\"  required></ion-input>\r\n            </ion-item>\r\n            <div class=\"validation-errors\">\r\n              <ng-container *ngFor=\"let validation of validation_messages.telf\">\r\n                <div class=\"error-message\" *ngIf=\"onRegisterForm.get('telf').touched && onRegisterForm.get('telf').hasError('telf')\">\r\n                  <ion-text color=\"warning\">\r\n                    {{ validation.message }}\r\n                  </ion-text>\r\n                </div>\r\n              </ng-container>\r\n            </div>\r\n            <ion-item>\r\n                <ion-label>Pais</ion-label>\r\n                <ion-select placeholder=\"Seleccionar Pais\" formControlName=\"country\" [(ngModel)]=\"country\" (ionChange)=\"onChange(country)\">\r\n                    <ion-select-option   *ngFor=\"let cc of currencyList\" value=\"{{ cc.name }}\"  >\r\n                        {{cc.name + ' ' + cc.code}}\r\n                     \r\n                    </ion-select-option>\r\n                </ion-select>\r\n              </ion-item>\r\n          </div>\r\n          \r\n       \r\n          <ion-button shape=\"round\" expand=\"full\" fill=\"outline\" color=\"tertiary\" [disabled]=\"!onRegisterForm.valid\" (click)=\"signUp()\" tappable>\r\n            <ion-icon name=\"log-in\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n\r\n \r\n  <div text-center margin-top>\r\n    <span (click)=\"goToLogin()\" tappable>\r\n      <ion-text color=\"light\">\r\n        <strong>Ya tengo una cuenta!</strong>\r\n      </ion-text>\r\n    </span>\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/register/register.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".error {\n  color: #df3e3e;\n  font-size: 11px; }\n\n.error1 {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000; }\n\n.validation-error {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000;\n  font-size: 11px; }\n\nion-item {\n  --color: #3880ff;\n  --background: #fff; }\n\nion-button {\n  --background: #062f77; }\n\n.flag-icon-background {\n  background-size: contain;\n  background-position: 50%;\n  background-repeat: no-repeat; }\n\n.flag-icon {\n  background-size: contain;\n  background-position: 50%;\n  background-repeat: no-repeat;\n  position: relative;\n  display: inline-block;\n  width: 1.33333333em;\n  line-height: 1em; }\n\n.alert-radio-group button:nth-child(1) .alert-radio-label:before {\n  content: url(/assets/img/avatar/avatar0.jpg); }\n\n.alert-radio-group button:nth-child(2) .alert-radio-label:before {\n  content: url(/assets/img/avatar/avatar1.jpg); }\n\n.alert-radio-group button:nth-child(3) .alert-radio-label:before {\n  content: url(/assets/img/avatar/avatar2.jpg); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcmVnaXN0ZXIvQzpcXGl0YmFcXHdzXFxwYXctMjAxOWEtNlxcQmFuY2FsZXRcXHdlYmFwcFxccmVzdGNsaWVudC9zcmNcXGFwcFxccGFnZXNcXHJlZ2lzdGVyXFxyZWdpc3Rlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUF1QjtFQUN2QixlQUFlLEVBQUE7O0FBR2pCO0VBQ0UsY0FBc0I7RUFDdEIsZ0NBQWdDLEVBQUE7O0FBR2xDO0VBQ0UsY0FBc0I7RUFDdEIsZ0NBQWdDO0VBQ2hDLGVBQWUsRUFBQTs7QUFFakI7RUFDRSxnQkFBUTtFQUNSLGtCQUFhLEVBQUE7O0FBR2pCO0VBQ0kscUJBQWEsRUFBQTs7QUFJakI7RUFDSSx3QkFBd0I7RUFDeEIsd0JBQXdCO0VBQ3hCLDRCQUE0QixFQUFBOztBQUU5QjtFQUNFLHdCQUF3QjtFQUN4Qix3QkFBd0I7RUFDeEIsNEJBQTRCO0VBQzVCLGtCQUFrQjtFQUNsQixxQkFBcUI7RUFDckIsbUJBQW1CO0VBQ25CLGdCQUFnQixFQUFBOztBQU9sQjtFQUNFLDRDQUE0QyxFQUFBOztBQUdoRDtFQUNJLDRDQUE0QyxFQUFBOztBQUdoRDtFQUNJLDRDQUE0QyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcmVnaXN0ZXIvcmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVycm9yIHtcclxuICAgIGNvbG9yOiByZ2IoMjIzLCA2MiwgNjIpO1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gIH1cclxuXHJcbiAgLmVycm9yMSB7XHJcbiAgICBjb2xvcjogcmdiKDc1LCA3NSwgNzUpO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjAwMDA7XHJcbiAgfVxyXG5cclxuICAudmFsaWRhdGlvbi1lcnJvciB7XHJcbiAgICBjb2xvcjogcmdiKDc1LCA3NSwgNzUpO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjAwMDA7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgfVxyXG4gIGlvbi1pdGVte1xyXG4gICAgLS1jb2xvcjogIzM4ODBmZjtcclxuICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxufVxyXG5cclxuaW9uLWJ1dHRvbntcclxuICAgIC0tYmFja2dyb3VuZDogIzA2MmY3NztcclxufVxyXG5cclxuICAgIFxyXG4uZmxhZy1pY29uLWJhY2tncm91bmQge1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogNTAlO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICB9XHJcbiAgLmZsYWctaWNvbiB7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiA1MCU7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDEuMzMzMzMzMzNlbTtcclxuICAgIGxpbmUtaGVpZ2h0OiAxZW07XHJcbiAgfVxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgLmFsZXJ0LXJhZGlvLWdyb3VwIGJ1dHRvbjpudGgtY2hpbGQoMSkgLmFsZXJ0LXJhZGlvLWxhYmVsOmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiB1cmwoL2Fzc2V0cy9pbWcvYXZhdGFyL2F2YXRhcjAuanBnKTtcclxufVxyXG5cclxuLmFsZXJ0LXJhZGlvLWdyb3VwIGJ1dHRvbjpudGgtY2hpbGQoMikgLmFsZXJ0LXJhZGlvLWxhYmVsOmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiB1cmwoL2Fzc2V0cy9pbWcvYXZhdGFyL2F2YXRhcjEuanBnKTtcclxufVxyXG5cclxuLmFsZXJ0LXJhZGlvLWdyb3VwIGJ1dHRvbjpudGgtY2hpbGQoMykgLmFsZXJ0LXJhZGlvLWxhYmVsOmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiB1cmwoL2Fzc2V0cy9pbWcvYXZhdGFyL2F2YXRhcjIuanBnKTtcclxufVxyXG4gIFxyXG4gIl19 */"

/***/ }),

/***/ "./src/app/pages/register/register.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/register/register.page.ts ***!
  \*************************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth/auth.service */ "./src/app/services/auth/auth.service.ts");
/* harmony import */ var _validators_password_validator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../validators/password.validator */ "./src/app/validators/password.validator.ts");
/* harmony import */ var src_app_services_users_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/users.service */ "./src/app/services/users.service.ts");







var RegisterPage = /** @class */ (function () {
    function RegisterPage(navCtrl, menuCtrl, loadingCtrl, formBuilder, authService, usersService, alertCtrl, toastCtrl) {
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.loadingCtrl = loadingCtrl;
        this.formBuilder = formBuilder;
        this.authService = authService;
        this.usersService = usersService;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.avatarId = 0;
        this.country = '';
        this.validation_messages = {
            'username': [
                { type: 'required', message: 'Debes introducir un nombre de usuario.' },
                { type: 'minlength', message: 'El nombre de usuario debe tener al menos 6 caracteres.' },
                { type: 'maxlength', message: 'El nombre de usuario no puede superar los 15 caracteres.' },
                { type: 'pattern', message: 'El usuario solamente puede contener números o letras.' },
                { type: 'validUsername', message: 'El usuario ya esta en uso.' }
            ],
            'telf': [
                { type: 'required', message: 'Debes introducir un número de telefono.' },
                { type: 'minlength', message: 'El número de telefono debe tener al menos 3 caracteres.' },
                { type: 'maxlength', message: 'El número de telefono no puede superar los 15 caracteres.' },
                { type: 'pattern', message: 'El número de telefono solamente puede contener números.' }
            ],
            'email': [
                { type: 'required', message: 'Debes introducir un email.' },
                { type: 'minlength', message: 'El email debe tener al menos 5 caracteres.' },
                { type: 'maxlength', message: 'El email no puede superar los 40 caracteres.' },
                { type: 'pattern', message: 'No es un email válido.' }
            ],
            'city': [
                { type: 'required', message: 'Debes introducir un ciudad.' },
                { type: 'minlength', message: 'La ciudad debe tener al menos 3 caracteres.' },
                { type: 'maxlength', message: 'La ciudad no puede superar los 40 caracteres.' },
            ],
            'country': [
                { type: 'required', message: 'Debes introducir un País.' },
                { type: 'minlength', message: 'El país debe tener al menos 3 caracteres.' },
                { type: 'maxlength', message: 'El país no puede superar los 40 caracteres.' },
            ],
            'direccion': [
                { type: 'required', message: 'Debes introducir un dirección.' },
                { type: 'minlength', message: 'La dirección debe tener al menos 3 caracteres.' },
                { type: 'maxlength', message: 'La dirección no puede superar los 150 caracteres.' },
            ],
            'code': [
                { type: 'required', message: 'Debes introducir un código.' },
                { type: 'minlength', message: 'El código debe tener al menos 3 caracteres.' },
                { type: 'maxlength', message: 'El código no puede superar los 40 caracteres.' },
                { type: 'pattern', message: 'El código solamente puede contener números o letras.' },
            ],
            'password': [
                { type: 'required', message: 'La contraseña es obligatoria.' },
                { type: 'minlength', message: 'La contraseña debe tener un tamaño mínimo de 6 caracteres.' },
                { type: 'maxlength', message: 'La contraseña no puede superar los 40 caracteres.' },
            ],
            'confirmPassword': [
                { type: 'required', message: 'Debes confirmar la contraseña.' },
                { type: 'minlength', message: 'La contraseña debe tener un tamaño mínimo de 6 caracteres.' },
                { type: 'maxlength', message: 'La contraseña no puede superar los 40 caracteres.' },
            ]
        };
        this.avatar_list = [
            '0',
            '1',
            '2',
            '3',
            '4',
            '5',
            '6'
        ];
    }
    RegisterPage.prototype.ionViewWillEnter = function () {
        this.menuCtrl.enable(false);
    };
    RegisterPage.prototype.ngOnInit = function () {
        var _this = this;
        this.usersService.getCountrys().then(function (response) {
            _this.currencyList = response;
        });
        this.onRegisterForm = this.formBuilder.group({
            numImg: this.avatarId,
            username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(15), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[a-zñÑA-Z0-9]+'), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            telf: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(15), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[0-9]+'), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$'), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            country: [this.country, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            direccion: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(150), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            code: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[a-zA-Z0-9]+'), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]))
        }, function (formGroup) {
            return _validators_password_validator__WEBPACK_IMPORTED_MODULE_5__["PasswordValidator"].areEqual(formGroup);
        });
    };
    RegisterPage.prototype.goToLogin = function () {
        this.navCtrl.navigateRoot('/');
    };
    RegisterPage.prototype.signUp = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.registerform = {
                            username: this.onRegisterForm.value.username,
                            password: this.onRegisterForm.value.password,
                            repeatPassword: this.onRegisterForm.value.confirmPassword,
                            telf: this.onRegisterForm.value.telf,
                            email: this.onRegisterForm.value.email,
                            city: this.onRegisterForm.value.city,
                            country: this.country,
                            code: this.onRegisterForm.value.code,
                            direccion: this.onRegisterForm.value.direccion,
                            numImg: this.avatarId,
                            lat: 0.0,
                            lon: 0.0
                        };
                        return [4 /*yield*/, this.alertCtrl.create({
                                header: 'Confirmación de registro',
                                message: '¿Estas seguro de que quieres crear un usuario con los datos introducidos?',
                                buttons: [
                                    {
                                        text: 'Cancelar',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                    }, {
                                        text: 'Confirmar',
                                        handler: function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                            var loading;
                                            var _this = this;
                                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                                switch (_a.label) {
                                                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                                                            message: 'Creando la cuenta... ',
                                                            translucent: true,
                                                        })];
                                                    case 1:
                                                        loading = _a.sent();
                                                        return [4 /*yield*/, loading.present()];
                                                    case 2:
                                                        _a.sent();
                                                        this.authService.register(this.registerform).then(function (value) {
                                                            _this.presentToast(value.data.mensaje);
                                                            loading.dismiss();
                                                            _this.navCtrl.navigateRoot('/');
                                                        }).catch(function (error) {
                                                            loading.dismiss();
                                                            if (error.toString().includes("403")) {
                                                                _this.presentToast('Ha surgido un problema: Los usuarios logeados no pueden crear cuentas.');
                                                            }
                                                            if (error.toString().includes("400")) {
                                                                _this.presentToast('Ha surgido un problema: Las contraseñas no coinciden.');
                                                            }
                                                            if (error.toString().includes("409")) {
                                                                _this.presentToast('Ha surgido un problema: El nombre de usuario o email ya existen.');
                                                            }
                                                        });
                                                        return [2 /*return*/];
                                                }
                                            });
                                        }); }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    RegisterPage.prototype.presentToast = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            showCloseButton: true,
                            message: text,
                            duration: 10000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    RegisterPage.prototype.onChange = function (country) {
        this.country = country;
    };
    RegisterPage.prototype.onChangeAvatar = function (avatar) {
        this.avatarId = avatar;
    };
    RegisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-register',
            template: __webpack_require__(/*! ./register.page.html */ "./src/app/pages/register/register.page.html"),
            styles: [__webpack_require__(/*! ./register.page.scss */ "./src/app/pages/register/register.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            src_app_services_users_service__WEBPACK_IMPORTED_MODULE_6__["UsersService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]])
    ], RegisterPage);
    return RegisterPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-register-register-module.js.map