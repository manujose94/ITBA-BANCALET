(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/legacy lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-controller_7.entry.js",
		13
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-ios.entry.js",
		"common",
		14
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-md.entry.js",
		"common",
		15
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-ios.entry.js",
		"common",
		16
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-md.entry.js",
		"common",
		17
	],
	"./ion-anchor_6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-anchor_6.entry.js",
		1,
		"common",
		18
	],
	"./ion-app_7-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-ios.entry.js",
		"common",
		19
	],
	"./ion-app_7-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-md.entry.js",
		"common",
		20
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-ios.entry.js",
		"common",
		21
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-md.entry.js",
		"common",
		22
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-ios.entry.js",
		"common",
		23
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-md.entry.js",
		"common",
		24
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-ios.entry.js",
		0,
		"common",
		25
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-md.entry.js",
		0,
		"common",
		26
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-ios.entry.js",
		"common",
		27
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-md.entry.js",
		"common",
		28
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-ios.entry.js",
		"common",
		29
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-md.entry.js",
		"common",
		30
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-ios.entry.js",
		"common",
		31
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-md.entry.js",
		"common",
		32
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-ios.entry.js",
		"common",
		33
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-md.entry.js",
		"common",
		34
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-col_3.entry.js",
		35
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-ios.entry.js",
		"common",
		36
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-md.entry.js",
		"common",
		37
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-ios.entry.js",
		"common",
		38
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-md.entry.js",
		"common",
		39
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-img.entry.js",
		40
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-ios.entry.js",
		"common",
		41
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-md.entry.js",
		"common",
		42
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-ios.entry.js",
		"common",
		43
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-md.entry.js",
		"common",
		44
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-ios.entry.js",
		"common",
		45
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-md.entry.js",
		"common",
		46
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-ios.entry.js",
		"common",
		47
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-md.entry.js",
		"common",
		48
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-ios.entry.js",
		"common",
		49
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-md.entry.js",
		"common",
		50
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-ios.entry.js",
		0,
		"common",
		51
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-md.entry.js",
		0,
		"common",
		52
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-ios.entry.js",
		1,
		"common",
		53
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-md.entry.js",
		1,
		"common",
		54
	],
	"./ion-nav_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-nav_4.entry.js",
		1,
		"common",
		55
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-ios.entry.js",
		1,
		"common",
		56
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-md.entry.js",
		1,
		"common",
		57
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-ios.entry.js",
		"common",
		58
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-md.entry.js",
		"common",
		59
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-ios.entry.js",
		"common",
		60
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-md.entry.js",
		"common",
		61
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-ios.entry.js",
		"common",
		62
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-md.entry.js",
		"common",
		63
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-ios.entry.js",
		"common",
		64
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-md.entry.js",
		"common",
		65
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-ios.entry.js",
		"common",
		66
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-md.entry.js",
		"common",
		67
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-ripple-effect.entry.js",
		68
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-ios.entry.js",
		"common",
		69
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-md.entry.js",
		"common",
		70
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-ios.entry.js",
		"common",
		71
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-md.entry.js",
		"common",
		72
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-ios.entry.js",
		"common",
		73
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-md.entry.js",
		"common",
		74
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-ios.entry.js",
		"common",
		75
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-md.entry.js",
		"common",
		76
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-spinner.entry.js",
		"common",
		77
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-ios.entry.js",
		78
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-md.entry.js",
		79
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-ios.entry.js",
		"common",
		80
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-md.entry.js",
		"common",
		81
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab_2.entry.js",
		"common",
		10
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-text.entry.js",
		"common",
		82
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-ios.entry.js",
		"common",
		83
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-md.entry.js",
		"common",
		84
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-ios.entry.js",
		"common",
		85
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-md.entry.js",
		"common",
		86
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-ios.entry.js",
		"common",
		87
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-md.entry.js",
		"common",
		88
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-virtual-scroll.entry.js",
		89
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../additem/additem.module": [
		"./src/app/pages/item/additem/additem.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"additem-additem-module"
	],
	"../archived-issues/archived-issues.module": [
		"./src/app/pages/admin/archived-issues/archived-issues.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"archived-issues-archived-issues-module"
	],
	"../first-tab/first-tab.module": [
		"./src/app/pages/first-tab/first-tab.module.ts",
		"first-tab-first-tab-module"
	],
	"../issues/issues.module": [
		"./src/app/pages/admin/issues/issues.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"issues-issues-module"
	],
	"../item/items/items.module": [
		"./src/app/pages/item/items/items.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"item-items-items-module"
	],
	"../item/myitems/myitems.module": [
		"./src/app/pages/item/myitems/myitems.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"item-myitems-myitems-module"
	],
	"../user/ayuda/ayuda.module": [
		"./src/app/pages/user/ayuda/ayuda.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-ayuda-ayuda-module"
	],
	"../user/miscontactados/miscontactados.module": [
		"./src/app/pages/user/miscontactados/miscontactados.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-miscontactados-miscontactados-module"
	],
	"../user/mismensajes/mismensajes.module": [
		"./src/app/pages/user/mismensajes/mismensajes.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"user-mismensajes-mismensajes-module"
	],
	"../user/misrecomendaciones/misrecomendaciones.module": [
		"./src/app/pages/user/misrecomendaciones/misrecomendaciones.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-misrecomendaciones-misrecomendaciones-module"
	],
	"../users/users.module": [
		"./src/app/pages/admin/users/users.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"users-users-module"
	],
	"./pages/admin/archived-issues/archived-issues.module": [
		"./src/app/pages/admin/archived-issues/archived-issues.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"archived-issues-archived-issues-module"
	],
	"./pages/admin/issue-details/issue-details.module": [
		"./src/app/pages/admin/issue-details/issue-details.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"pages-admin-issue-details-issue-details-module"
	],
	"./pages/admin/issues/issues.module": [
		"./src/app/pages/admin/issues/issues.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"issues-issues-module"
	],
	"./pages/admin/tabs-admin/tabs-admin.module": [
		"./src/app/pages/admin/tabs-admin/tabs-admin.module.ts",
		"pages-admin-tabs-admin-tabs-admin-module"
	],
	"./pages/admin/users/users.module": [
		"./src/app/pages/admin/users/users.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"users-users-module"
	],
	"./pages/confirmregister/confirmregister.module": [
		"./src/app/pages/confirmregister/confirmregister.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe",
		"common",
		"pages-confirmregister-confirmregister-module"
	],
	"./pages/first-tab/first-tab.module": [
		"./src/app/pages/first-tab/first-tab.module.ts",
		"first-tab-first-tab-module"
	],
	"./pages/item/additem/additem.module": [
		"./src/app/pages/item/additem/additem.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"additem-additem-module"
	],
	"./pages/item/edititem/edititem.module": [
		"./src/app/pages/item/edititem/edititem.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"pages-item-edititem-edititem-module"
	],
	"./pages/item/item-details/item-details.module": [
		"./src/app/pages/item/item-details/item-details.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"pages-item-item-details-item-details-module"
	],
	"./pages/item/items/items.module": [
		"./src/app/pages/item/items/items.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"item-items-items-module"
	],
	"./pages/item/myitems/myitems.module": [
		"./src/app/pages/item/myitems/myitems.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"item-myitems-myitems-module"
	],
	"./pages/login/login.module": [
		"./src/app/pages/login/login.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe",
		"common",
		"pages-login-login-module"
	],
	"./pages/menu/menu.module": [
		"./src/app/pages/menu/menu.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe",
		"common",
		"pages-menu-menu-module"
	],
	"./pages/register/register.module": [
		"./src/app/pages/register/register.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"default~pages-confirmregister-confirmregister-module~pages-login-login-module~pages-menu-menu-module~2f3f5afe",
		"common",
		"pages-register-register-module"
	],
	"./pages/user/ayuda/ayuda.module": [
		"./src/app/pages/user/ayuda/ayuda.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-ayuda-ayuda-module"
	],
	"./pages/user/editpass/editpass.module": [
		"./src/app/pages/user/editpass/editpass.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"pages-user-editpass-editpass-module"
	],
	"./pages/user/edituser/edituser.module": [
		"./src/app/pages/user/edituser/edituser.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"pages-user-edituser-edituser-module"
	],
	"./pages/user/miscontactados/miscontactados.module": [
		"./src/app/pages/user/miscontactados/miscontactados.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-miscontactados-miscontactados-module"
	],
	"./pages/user/mismensajes/mismensajes.module": [
		"./src/app/pages/user/mismensajes/mismensajes.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"default~additem-additem-module~item-items-items-module~item-myitems-myitems-module~pages-confirmregi~1c48ae90",
		"common",
		"user-mismensajes-mismensajes-module"
	],
	"./pages/user/misrecomendaciones/misrecomendaciones.module": [
		"./src/app/pages/user/misrecomendaciones/misrecomendaciones.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"user-misrecomendaciones-misrecomendaciones-module"
	],
	"./pages/user/user/user.module": [
		"./src/app/pages/user/user/user.module.ts",
		"default~additem-additem-module~archived-issues-archived-issues-module~issues-issues-module~item-item~1f04df8d",
		"common",
		"pages-user-user-user-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', loadChildren: './pages/login/login.module#LoginPageModule' },
    { path: 'menu', loadChildren: './pages/menu/menu.module#MenuPageModule' },
    { path: 'register', loadChildren: './pages/register/register.module#RegisterPageModule' },
    { path: 'additem', loadChildren: './pages/item/additem/additem.module#AdditemPageModule' },
    { path: 'items', loadChildren: './pages/item/items/items.module#ItemsPageModule' },
    { path: 'myitems', loadChildren: './pages/item/myitems/myitems.module#MyitemsPageModule' },
    { path: 'first-tab', loadChildren: './pages/first-tab/first-tab.module#FirstTabPageModule' },
    { path: 'item-details/:id', loadChildren: './pages/item/item-details/item-details.module#ItemDetailsPageModule' },
    { path: 'user/:id', loadChildren: './pages/user/user/user.module#UserPageModule' },
    { path: 'miscontactados', loadChildren: './pages/user/miscontactados/miscontactados.module#MiscontactadosPageModule' },
    { path: 'mismensajes', loadChildren: './pages/user/mismensajes/mismensajes.module#MismensajesPageModule' },
    { path: 'misrecomendaciones', loadChildren: './pages/user/misrecomendaciones/misrecomendaciones.module#MisrecomendacionesPageModule' },
    { path: 'edititem/:id', loadChildren: './pages/item/edititem/edititem.module#EdititemPageModule' },
    { path: 'confirmregister/:id', loadChildren: './pages/confirmregister/confirmregister.module#ConfirmregisterPageModule' },
    { path: 'ayuda', loadChildren: './pages/user/ayuda/ayuda.module#AyudaPageModule' },
    { path: 'issues', loadChildren: './pages/admin/issues/issues.module#IssuesPageModule' },
    { path: 'users', loadChildren: './pages/admin/users/users.module#UsersPageModule' },
    { path: 'archived-issues', loadChildren: './pages/admin/archived-issues/archived-issues.module#ArchivedIssuesPageModule' },
    { path: 'tabs-admin', loadChildren: './pages/admin/tabs-admin/tabs-admin.module#TabsAdminPageModule' },
    { path: 'edituser/:id', loadChildren: './pages/user/edituser/edituser.module#EdituserPageModule' },
    { path: 'editpass/:id', loadChildren: './pages/user/editpass/editpass.module#EditpassPageModule' },
    { path: 'issue-details/:id', loadChildren: './pages/admin/issue-details/issue-details.module#IssueDetailsPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./providers/settings */ "./src/app/providers/settings.ts");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, settings) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.settings = settings;
        this.settings.load().then(function () {
        });
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _providers_settings__WEBPACK_IMPORTED_MODULE_5__["SettingsProvider"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: provideSettings, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "provideSettings", function() { return provideSettings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _providers_settings__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./providers/settings */ "./src/app/providers/settings.ts");












function provideSettings(storage) {
    return new _providers_settings__WEBPACK_IMPORTED_MODULE_11__["SettingsProvider"](storage, {
        AuthToken: null
    });
}
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_storage__WEBPACK_IMPORTED_MODULE_10__["IonicStorageModule"].forRoot(), _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"]],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _providers_settings__WEBPACK_IMPORTED_MODULE_11__["SettingsProvider"], useFactory: provideSettings, deps: [_ionic_storage__WEBPACK_IMPORTED_MODULE_10__["Storage"]] },
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/providers/settings.ts":
/*!***************************************!*\
  !*** ./src/app/providers/settings.ts ***!
  \***************************************/
/*! exports provided: SettingsProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsProvider", function() { return SettingsProvider; });
var SettingsProvider = /** @class */ (function () {
    function SettingsProvider(storage, defaults) {
        this.storage = storage;
        this.SETTINGS_KEY = '_settings';
        this._defaults = defaults;
    }
    SettingsProvider.prototype.load = function () {
        var _this = this;
        return this.storage.get(this.SETTINGS_KEY).then(function (value) {
            if (value) {
                _this.settings = value;
                return _this._mergeDefaults(_this._defaults);
            }
            else {
                return _this.setAll(_this._defaults).then(function (val) {
                    _this.settings = val;
                });
            }
        });
    };
    SettingsProvider.prototype._mergeDefaults = function (defaults) {
        for (var k in defaults) {
            if (!(k in this.settings)) {
                this.settings[k] = defaults[k];
            }
        }
        return this.setAll(this.settings);
    };
    SettingsProvider.prototype.merge = function (settings) {
        for (var k in settings) {
            this.settings[k] = settings[k];
        }
        return this.save();
    };
    SettingsProvider.prototype.setValue = function (key, value) {
        this.settings[key] = value;
        return this.storage.set(this.SETTINGS_KEY, this.settings);
    };
    SettingsProvider.prototype.setAll = function (value) {
        return this.storage.set(this.SETTINGS_KEY, value);
    };
    SettingsProvider.prototype.getValue = function (key) {
        return this.storage.get(this.SETTINGS_KEY)
            .then(function (settings) {
            return settings[key];
        });
    };
    SettingsProvider.prototype.save = function () {
        return this.setAll(this.settings);
    };
    Object.defineProperty(SettingsProvider.prototype, "allSettings", {
        get: function () {
            return this.settings;
        },
        enumerable: true,
        configurable: true
    });
    SettingsProvider.prototype.storeUserCredentials = function (token) {
        window.localStorage.setItem('token', token);
        this.setUserCredentials(token);
    };
    SettingsProvider.prototype.storeUserInfo = function (user, userID) {
        window.localStorage.setItem('user', user);
        window.localStorage.setItem('userID', userID);
        this.settings['user'] = user;
        this.settings['userID'] = userID;
        this.storage.set(this.SETTINGS_KEY, this.settings);
    };
    SettingsProvider.prototype.setUserCredentials = function (token) {
        this.settings['AuthToken'] = token;
        this.settings['isLoggedIn'] = true;
        return this.storage.set(this.SETTINGS_KEY, this.settings);
    };
    SettingsProvider.prototype.remove = function (key) {
        this.storage.remove(key);
    };
    return SettingsProvider;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\itba\ws\paw-2019a-6\Bancalet\webapp\restclient\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map