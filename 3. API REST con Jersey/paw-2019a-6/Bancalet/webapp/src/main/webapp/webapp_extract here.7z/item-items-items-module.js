(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["item-items-items-module"],{

/***/ "./src/app/pages/item/items/items.module.ts":
/*!**************************************************!*\
  !*** ./src/app/pages/item/items/items.module.ts ***!
  \**************************************************/
/*! exports provided: ItemsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsPageModule", function() { return ItemsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _items_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./items.page */ "./src/app/pages/item/items/items.page.ts");







var routes = [
    {
        path: '',
        component: _items_page__WEBPACK_IMPORTED_MODULE_6__["ItemsPage"],
        children: [
            {
                path: 'addItem',
                loadChildren: '../additem/additem.module#AdditemPageModule'
            }
        ]
    }
];
var ItemsPageModule = /** @class */ (function () {
    function ItemsPageModule() {
    }
    ItemsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_items_page__WEBPACK_IMPORTED_MODULE_6__["ItemsPage"]]
        })
    ], ItemsPageModule);
    return ItemsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/item/items/items.page.html":
/*!**************************************************!*\
  !*** ./src/app/pages/item/items/items.page.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button>\r\n            <i class=\" material-icons\">menu</i>\r\n        </ion-menu-button>\r\n      </ion-buttons>\r\n      <ion-title>Productos</ion-title>\r\n    </ion-toolbar>\r\n    <!-- fab placed to the top end -->\r\n    <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\" >\r\n            <ion-fab-button color=\"success\" expand=\"block\" routerLink=\"/additem\" routerDirection=\"forward\">\r\n              <i class=\" material-icons\">add</i>\r\n            </ion-fab-button>\r\n          </ion-fab>\r\n\r\n          <ion-searchbar [(ngModel)]=\"searchItem\" (ionChange)=\"searchTipoChanged()\"></ion-searchbar>\r\n          <ion-item>\r\n          <ion-label>Seleccionar Tipo</ion-label>\r\n          <ion-avatar *ngIf=\"tipoSelected\">\r\n              <img src=\"assets/img/type_food/{{tipoSelected}}.png\">\r\n          </ion-avatar>\r\n          <ion-select [(ngModel)]=\"type\" (ionChange)=\"searchTipoChanged()\">\r\n            <ion-select-option value=\"\" selected>Todos</ion-select-option>\r\n            <ion-select-option   *ngFor=\"let tipo of tipos\" value=\"{{tipo.id}}\"  >\r\n                {{ tipo.name}}                   \r\n              </ion-select-option> \r\n            </ion-select>\r\n          </ion-item>\r\n         \r\n              <ion-grid>\r\n                  <ion-row>\r\n                    <ion-col size=\"6\" size-sm>\r\n                        <ion-item>\r\n                        <ion-label>Tipo de Caducidad</ion-label>\r\n                        <ion-select [(ngModel)]=\"itemTipoCaducidad\" (ionChange)=\"itemTipoCaducidadChanged()\" interface=\"action-sheet\">\r\n                          <ion-select-option value=\"\" selected>Anular</ion-select-option>\r\n                          <ion-select-option value=\"1\" selected>Menor a</ion-select-option>\r\n                          <ion-select-option value=\"2\" selected>Mayor a</ion-select-option>   \r\n                      </ion-select>\r\n                    </ion-item>\r\n        </ion-col>\r\n        <ion-col  size=\"6\">\r\n            <ion-item lines=\"none\" > \r\n             <i class=\" material-icons\">date_range</i>\r\n            <ion-label position=\"floating\">Fecha </ion-label>\r\n            <ion-datetime disabled=\"{{!itemTipoCaducidad}}\" name=\"fecha_caducidad\" [(ngModel)]=\"fecha_caducidad\" displayFormat=\"YYYY-MM-DD\" placeholder=\"{{today}}\" min=\"{{today}}\" max=\"2040-12-09\">  \r\n            </ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n      \r\n\r\n          <ion-list>\r\n              <ion-list-header>\r\n                  <ion-grid>\r\n                      <ion-row>\r\n                        <ion-col size=\"6\" size-sm>\r\n                  <ion-item lines=\"none\">Rango Precio &nbsp; &nbsp;&nbsp; \r\n                      <ion-badge item-end color=\"dark\">{{slider.lower}}</ion-badge>\r\n                      &nbsp;-&nbsp;\r\n                      <ion-badge item-end color=\"dark\">{{slider.upper}}</ion-badge>\r\n                     \r\n                    </ion-item>\r\n                  </ion-col>\r\n                  <ion-col size=\"6\" align-items-end size-sm>\r\n                      <ion-button shape=\"round\" (click)=\"searchTipoChanged()\" disabled=\"{{ !onFiltro }}\"> <i class=\" material-icons\">search</i></ion-button>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n              \r\n              </ion-list-header>\r\n              <ion-item lines=\"none\">\r\n                <ion-range dualKnobs=\"true\" pin=\"true\" min={{min}} max={{max}} [(ngModel)]=\"slider\" (ionChange)=\"onSliderChange(slider)\" color=\"dark\">\r\n                  <ion-label range-left>{{min}}</ion-label>\r\n                  <ion-label range-right>{{max}}</ion-label>\r\n                  <ion-icon slot=\"start\" size=\"small\" name=\"cash\"></ion-icon>\r\n                  <ion-icon slot=\"end\" name=\"cash\"></ion-icon>\r\n                </ion-range>\r\n              </ion-item>\r\n            </ion-list>\r\n          \r\n  </ion-header>\r\n  \r\n    <ion-content>\r\n       \r\n\r\n        <ion-refresher slot=\"fixed\" \r\n        (ionRefresh)=\"ionRefresh($event)\" \r\n        (ionPull)=\"ionPull($event)\" \r\n        (ionStart)=\"ionStart($event)\">\r\n          <ion-refresher-content\r\n            pullingIcon=\"arrow-dropdown\"\r\n            pullingText=\"Tirar para refrescar\"\r\n            refreshingSpinner=\"circles\"\r\n            refreshingText=\"Actualizando...\">\r\n          </ion-refresher-content>\r\n        </ion-refresher>\r\n\r\n      <ion-content>\r\n            \r\n     \r\n      \r\n       \r\n        \r\n    <ion-list>    \r\n     <ion-item button *ngFor=\"let item of items\" [routerLink]=\"['/', 'item-details', item.key]\">\r\n      <ion-avatar slot=\"start\">\r\n          <img src=\"assets/img/type_food/{{item.value.tipo}}.png\">\r\n      </ion-avatar>\r\n      <ion-row>\r\n          <ion-col>            \r\n                  <ion-label class=\"notification-title\" >{{ item.value.name }}&nbsp; &nbsp; <small class=\"date-notification\"><strong>Publicado: </strong>&nbsp; {{ item.value.fechaPublicacion.substring(0,10) }}</small> </ion-label>\r\n                  <p class=\"text-notification\"><i class=\" material-icons\">monetization_on</i> &nbsp;Precio: {{ item.value.price }}$ </p> \r\n                  <p class=\"text-notification\"><i class=\" material-icons\">event</i>&nbsp;Fecha Caducidad : {{ item.value.fechaCaducidad.substring(0,10) }} </p> \r\n          </ion-col>\r\n      </ion-row>\r\n      \r\n     </ion-item>\r\n     \r\n        \r\n        </ion-list>\r\n     \r\n    </ion-content>\r\n\r\n    <script>\r\n        const dualRange = document.querySelector('#dual-range');\r\n        dualRange.value = { lower: 33, upper: 60 };\r\n    </script>\r\n"

/***/ }),

/***/ "./src/app/pages/item/items/items.page.scss":
/*!**************************************************!*\
  !*** ./src/app/pages/item/items/items.page.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".notification-title {\n  font-size: 15px; }\n\n.notification-informations {\n  padding-left: 5px;\n  height: 35px; }\n\n.date-notification {\n  margin-left: -8px;\n  font-size: 8px;\n  color: darkgray; }\n\n.text-notification {\n  font-weight: 500;\n  font-size: 13px;\n  margin-top: 4px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaXRlbS9pdGVtcy9DOlxcaXRiYVxcd3NcXHBhdy0yMDE5YS02XFxCYW5jYWxldFxcd2ViYXBwXFxyZXN0Y2xpZW50L3NyY1xcYXBwXFxwYWdlc1xcaXRlbVxcaXRlbXNcXGl0ZW1zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQWUsRUFBQTs7QUFFbkI7RUFDSSxpQkFBaUI7RUFDakIsWUFBWSxFQUFBOztBQUVoQjtFQUNJLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsZUFBZSxFQUFBOztBQUduQjtFQUNJLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBZSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaXRlbS9pdGVtcy9pdGVtcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubm90aWZpY2F0aW9uLXRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4ubm90aWZpY2F0aW9uLWluZm9ybWF0aW9ucyB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgIGhlaWdodDogMzVweDtcclxufVxyXG4uZGF0ZS1ub3RpZmljYXRpb24ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IC04cHg7XHJcbiAgICBmb250LXNpemU6IDhweDtcclxuICAgIGNvbG9yOiBkYXJrZ3JheTtcclxuICBcclxufVxyXG4udGV4dC1ub3RpZmljYXRpb24ge1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIG1hcmdpbi10b3A6IDRweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/item/items/items.page.ts":
/*!************************************************!*\
  !*** ./src/app/pages/item/items/items.page.ts ***!
  \************************************************/
/*! exports provided: ItemsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsPage", function() { return ItemsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_items_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/items.service */ "./src/app/services/items.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var ItemsPage = /** @class */ (function () {
    function ItemsPage(alertController, loadingCtrl, events, itemsService) {
        this.alertController = alertController;
        this.loadingCtrl = loadingCtrl;
        this.events = events;
        this.itemsService = itemsService;
        this.searchItem = '';
        this.slider = { lower: 0, upper: 0 };
        this.onFiltro = false;
        this.tipos = this.itemsService.getTipos();
    }
    ItemsPage.prototype.ngOnInit = function () {
        this.initActualDate();
        this.getItems();
    };
    ItemsPage.prototype.initActualDate = function () {
        var today = new Date();
        var day = new Date().getDate();
        var mounth = today.getMonth() + 1;
        var dd;
        var mm;
        var yyyy = today.getFullYear();
        if (day < 10) {
            dd = '0' + day;
        }
        else {
            dd = day.toString();
        }
        if (mounth < 10) {
            mm = '0' + mounth;
        }
        else {
            mm = mounth.toString();
        }
        this.today = yyyy + '-' + mm + '-' + dd;
    };
    ItemsPage.prototype.showError = function (text) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Problema',
                            subHeader: 'Algo ha ocurrido a obtener items',
                            message: text,
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ItemsPage.prototype.onSliderChange = function (ev) {
        this.slider = ev;
    };
    ItemsPage.prototype.searchTipoChanged = function () {
        this.onFiltro = true;
        this.tipoSelected = this.type;
        if (this.fecha_caducidad) {
            this.fecha_caducidad = this.fecha_caducidad.substring(0, 11);
        }
        this.getItemsFiltro(this.searchItem, this.tipoSelected, this.slider.lower, this.slider.upper, this.itemTipoCaducidad, this.fecha_caducidad);
    };
    ItemsPage.prototype.itemTipoCaducidadChanged = function () {
        this.onFiltro = true;
    };
    ItemsPage.prototype.getItems = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando productos..',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.itemsService.getItems().then(function (value) {
                            _this.max = value.data.max;
                            _this.min = value.data.min;
                            _this.slider = { lower: _this.min, upper: _this.max };
                            _this.items = value.data.items.entry;
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ItemsPage.prototype.getItemsFiltro = function (name, tipo, min, max, itemTipoCaducidad, fecha_caducidad) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            message: 'Cargando filtros...',
                            translucent: true,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        this.itemsService.getItemsFiltro(name, tipo, min, max, itemTipoCaducidad, fecha_caducidad).then(function (value) {
                            _this.items = value.data.items.entry;
                            loading.dismiss();
                        }).catch(function (error) {
                            if (!error.response) {
                                error.response = 'ERROR';
                            }
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ItemsPage.prototype.ionRefresh = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getItems()];
                    case 1:
                        _a.sent();
                        event.target.complete();
                        return [2 /*return*/];
                }
            });
        });
    };
    ItemsPage.prototype.ionViewDidEnter = function () {
        this.getItems();
    };
    ItemsPage.prototype.ionPull = function (event) {
    };
    ItemsPage.prototype.ionStart = function (event) {
    };
    ItemsPage.prototype.ionViewCanEnter = function () {
    };
    ItemsPage.prototype.ionViewWillEnter = function () {
    };
    ItemsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-items',
            template: __webpack_require__(/*! ./items.page.html */ "./src/app/pages/item/items/items.page.html"),
            styles: [__webpack_require__(/*! ./items.page.scss */ "./src/app/pages/item/items/items.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"],
            src_app_services_items_service__WEBPACK_IMPORTED_MODULE_2__["ItemsService"]])
    ], ItemsPage);
    return ItemsPage;
}());



/***/ })

}]);
//# sourceMappingURL=item-items-items-module.js.map